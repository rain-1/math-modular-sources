# Status: what is still assumed, and what is proved

Last checked against the current sources: `lake build` completes successfully (all targets, no
warnings), there is no `sorry` and no `axiom` anywhere in `RequestProject/`, and

```
#print axioms Catalan.catalan_worthiness_uncond_catalan
  -- depends on axioms: [propext, Classical.choice, Quot.sound]
```

i.e. only Lean's three standard axioms.

Everything quoted from the literature is carried as an **explicit hypothesis** of the theorem that
uses it, so nothing is smuggled in as an axiom.

---

## The one remaining hypothesis: `rate_D` (the prime number theorem)

The headline theorem is now

```lean
theorem Catalan.catalan_worthiness_uncond_catalan
    (rate_D : LogRate (fun N => ((Dlcm N : ℕ) : ℝ)) 1) :
    ∃ q p : ℕ → ℤ, IsAdmissible catalanReal q p ∧
      ((0.857914 : ℝ) : EReal) ≤ worthiness catalanReal q p
```

with the single hypothesis `log D_N = N + o(N)`, `D_N = lcm(1, …, N)`.  This is the prime number
theorem (in the form `ψ(N) ∼ N`), which was deliberately left as a hypothesis at the user's
request; Mathlib currently proves only Chebyshev-type bounds
(`Mathlib/NumberTheory/Chebyshev.lean`), not the asymptotic itself.

The general form of the theorem, `Catalan.catalan_worthiness_uncond_gt`, still takes the
structure `Catalan.BaseNoteInputs α` (`RequestProject/Assembly.lean`), whose three fields are
`alpha_eq_E : α = G_E`, `alpha_eq_Z : α = G_Z` and `rate_D`.  For `α = G` (Catalan's constant)
the first two fields are now *proved*, which is why the corollary above needs only `rate_D`.

---

## What used to be assumed and is now proved

* `G_E = G`: the limit of the modular row `2 B_n / A_n` **is** Catalan's constant
  (`EAbelLimit.lean`, `Catalan.GEreal_eq_catalanReal`).  The proof is self-contained:
  * the accelerated series `∑_j 4^j/(C(2j,j)(2j+1)²) = 2G` (`CatalanIntegral.lean`,
    `Catalan.tsum_wR`), proved from Wallis' integral `∫_0^1 (1−y²)^j dy = 4^j/((2j+1)C(2j,j))`,
    the rational substitution `y = 2u/(1+u²)`, termwise summation of `∑_j z^{2j+1}/(2j+1)`, and
    `∫_0^1 log u/(1+u²) du = −G`;
  * convergence of the closed-form weights `c_k → G/2` (`CatalanAccel.lean`);
  * the Legendre-variable generating functions `F(w) = ∑ C(2k,k)² w^k`,
    `Γ(w) = ∑ C(2k,k)² c_k w^k` and the identities `f_A(x) = F(x(1−4x))`, `f_B(x) = Γ(x(1−4x))`
    (`AnalyticTools.lean`, `EClosedFormA.lean`, `EGenFun.lean`);
  * an Abel-type argument at `x → 1/8⁻`: `F(w) → ∞`, so `Γ/F → G/2`, while the generating
    function of the linear forms `ℓ_n = (G_E/2)A_n − B_n` stays bounded, so `f_B/f_A → G_E/2`
    (`EAbelLimit.lean`);
* `G_Z = G`: the limit of the Zudilin row *is* Catalan's constant (`ZudilinLimit.lean`, from
  Rivoal's identity);
* the closed form `B_n = ∑_{k ≤ n} C(2k,k)² c_k (-4)^{n-k} C(k,n-k)` with
  `c_k = (1/4) ∑_{j<k} 4^j/(C(2j,j)(2j+1)²)` (`EClosedForm.lean`), and with it the integrality
  half of Imported Theorem E, `D_n² B_n ∈ ℤ` (`EIntegralityB.lean`, resting on the arithmetic
  estimate `4·C(2j,j)·(2j+1)² ∣ D_k²·C(2k,k)²·4^j` for `j < k` of `EDenominator.lean`);
  the integer first-row numerator is the explicit sequence `y1row`;
* `A_n ∈ ℤ` and the closed form `A_n = ∑_k C(n,k)C(2k,k)C(2n−2k,n−k)` (`EIntegrality.lean`);
* `(1/n) log A_n → log 8` (`ERate.lean`, equation (9.2));
* `(1/m) log Q_m → 5 log φ` (`ZRatio.lean`);
* convergence of both rows, and the two linear-form rates
  `(1/n) log |G_E A_n/2 − B_n| → log 4` and `(1/m) log |Q_m G_Z − P_m| → −5 log φ`
  (`LinearForms.lean`, equations (9.3) and Imported Theorem Z, second half);
* `α ≠ 0`, and the growth rates of `B_n` and of `P_m` (derived in `Assembly.lean`);
* `2^e Q_m ∈ ℤ` for `e ≥ 4m`, in particular for the clearing exponents `e_{3n}` of (5.1)
  (`ZIntegrality.lean`, with the Legendre bound along an arithmetic progression in
  `APValuation.lean`) — this is Lemma 5.1 for the row `X₂`;
* Rivoal's `q_m(x_m) = Q_m` (`RivoalQ.lean`), his numerator identity (4.9) (`RivoalP.lean`),
  Beukers' functional equation (`XiSeries.lean`) and his 2-adic Padé estimate
  (`PadeEstimate.lean`);
* the integrality of the second (Zudilin) numerator row, `Y₂ n = 2^{e_{3n}} S n P_{3n} ∈ ℤ`
  (`Y2Integrality.lean`), so the integer row is the explicit sequence `y2row`;
* the whole geometry-of-numbers step (`GeometrySelection.lean`) and the exact `2`-adic
  cross-realization valuation (`Plucker.lean`, `CrossIdentity.lean`, `Assembly.lean`).
