# A Conditional \(0.857914\) Catalan Worthiness Theorem from a \(2\)-adic Cross-Realization Congruence

## 0. Status and formalization convention

Let

\[
G=\beta(2)=\sum_{k=0}^{\infty}\frac{(-1)^k}{(2k+1)^2}
\]

denote Catalan's constant.

This note proves, conditional on exactly one explicitly isolated arithmetic statement, the existence of an admissible sequence of rational approximations to \(G\) having construction quality

\[
\boxed{
\delta_{\mathrm{Cat}}
\ge
\frac{30\log\phi}
{6+\frac{45}{2}\log\phi}
=
0.8579144524736175393706930538\ldots,
}
\]

where

\[
\phi=\frac{1+\sqrt5}{2}.
\]

The unresolved statement is:

> **Gap Lemma.**
> For every integer \(m\ge1\),
> \[
> \boxed{
> v_2\!\left(
> P_mA_{2m}-2B_{2m}Q_m
> \right)=4m-1.
> }
> \tag{G}
> \]

Here \(P_m,Q_m\) are Zudilin's Catalan sequences and \(A_n,B_n\) are the modular \(E\)-family Catalan sequences defined below.

Everything else in this document is either proved explicitly below or is listed as an imported theorem with its precise required content.

The Gap Lemma may equivalently be replaced by the statement that the two rational sequences

\[
\frac{P_m}{Q_m},
\qquad
\frac{2B_m}{A_m}
\]

have the same limit in \(\mathbf Q_2\). This equivalence is proved below.

No assertion that \(G\) is irrational is made.

---

# 1. Construction quality

## Definition 1.1: admissible approximation sequence

Let \(\alpha\in\mathbf R\).

An **admissible approximation sequence** to \(\alpha\) is a sequence

\[
(q_n,p_n)\in\mathbf Z^2
\]

defined for all sufficiently large \(n\), satisfying

\[
q_n\ne0,
\qquad
q_n\alpha-p_n\ne0,
\qquad
|q_n|\longrightarrow\infty.
\]

## Definition 1.2: construction quality or worthiness

For an admissible approximation sequence define

\[
\delta(q,p)
=
\liminf_{n\to\infty}
\frac{-\log|\alpha-p_n/q_n|}
{\log|q_n|}.
\]

We shall also call \(\delta(q,p)\) the **worthiness** of the displayed construction.

Since

\[
\alpha-\frac{p_n}{q_n}
=
\frac{q_n\alpha-p_n}{q_n},
\]

if

\[
\log|q_n|=Hn+o(n)
\]

and

\[
\log|q_n\alpha-p_n|\le Fn+o(n),
\]

with \(H>0\), then

\[
\delta(q,p)\ge 1-\frac FH.
\]

If \(\alpha=a/b\in\mathbf Q\) in lowest terms and \(q\alpha-p\ne0\), then

\[
|q\alpha-p|
=
\frac{|aq-bp|}{|b|}
\ge\frac1{|b|}.
\]

Consequently every admissible approximation sequence to a rational number has

\[
\delta(q,p)\le1.
\]

Thus the threshold \(1\) is the natural irrationality threshold for this notion of worthiness.

---

# 2. Elementary notation

For \(N\ge1\), define

\[
D_N=\operatorname{lcm}(1,2,\ldots,N).
\]

Let \(v_2(x)\) be the usual \(2\)-adic valuation on \(\mathbf Q^\times\), normalized by

\[
v_2(2)=1.
\]

Set

\[
v_2(0)=+\infty.
\]

For \(n\ge0\), let \(s_2(n)\) be the sum of the binary digits of \(n\).

We use repeatedly the prime-number-theorem consequence

\[
\boxed{
\log D_N=N+o(N).
}
\tag{2.1}
\]

---

# 3. Binary digit identities

## Lemma 3.1

For every integer \(m\ge1\),

\[
s_2(m-1)=s_2(m)-1+v_2(m).
\tag{3.1}
\]

For every integer \(m\ge0\),

\[
s_2(m+1)=s_2(m)+1-v_2(m+1).
\tag{3.2}
\]

### Proof

Write

\[
m=2^r u,
\qquad u\ \text{odd},
\qquad r=v_2(m).
\]

In binary, \(m\) ends in exactly \(r\) zero digits.

Subtracting \(1\) changes the last nonzero binary digit from \(1\) to \(0\), and changes the final \(r\) zero digits to \(r\) ones. Therefore

\[
s_2(m-1)=s_2(m)-1+r.
\]

This proves (3.1).

Equation (3.2) is the same statement applied to \(m+1\):

\[
s_2(m)=s_2(m+1)-1+v_2(m+1).
\]

Rearrange. \(\square\)

---

# 4. Zudilin's Catalan recurrence

Define

\[
\varphi(m)=20m^2-8m+1.
\]

For \(m\ge1\), define the recurrence

\[
\begin{aligned}
&(2m+1)^2(2m+2)^2\varphi(m)z_{m+1}\\
&\qquad=
C_mz_m
+
(2m-1)^2(2m)^2\varphi(m+1)z_{m-1},
\end{aligned}
\tag{4.1}
\]

where

\[
C_m
=
3520m^6+5632m^5+2064m^4
-384m^3-156m^2+16m+7.
\]

Define two solutions by

\[
(Q_0,Q_1)=\left(1,\frac74\right),
\]

and

\[
(P_0,P_1)=\left(0,\frac{13}{8}\right).
\]

We import the following established properties of this row.

## Imported Theorem Z

The sequences \(Q_m,P_m\) satisfy:

1. Archimedean Catalan limit:
   \[
   \frac{P_m}{Q_m}\to G.
   \]

2. Archimedean exponential rates:
   \[
   \frac1m\log|Q_m|\to5\log\phi,
   \]
   \[
   \frac1m\log|Q_mG-P_m|\to-5\log\phi.
   \]

3. Denominator bounds:
   \[
   2^{4m+3}D_mQ_m\in\mathbf Z,
   \]
   \[
   2^{4m+3}D_{2m-1}^3P_m\in\mathbf Z,
   \]
   \[
   2^{6m}Q_m\in\mathbf Z,
   \]
   \[
   2^{6m}D_{2m-1}^2P_m\in\mathbf Z.
   \]

These are taken as imported inputs.

---

# 5. A convenient integral normalization of the Zudilin row

For \(m\ge1\), put

\[
e_m
=
\min
\left\{
6m,\,
4m+3+\lfloor\log_2(2m-1)\rfloor
\right\}.
\tag{5.1}
\]

## Lemma 5.1

For every \(m\ge1\),

\[
2^{e_m}Q_m\in\mathbf Z,
\tag{5.2}
\]

and

\[
2^{e_m}D_{2m-1}^2P_m\in\mathbf Z.
\tag{5.3}
\]

Moreover

\[
e_m=4m+O(\log m).
\tag{5.4}
\]

### Proof

By Imported Theorem Z,

\[
2^{6m}Q_m\in\mathbf Z.
\]

The alternative bound

\[
2^{4m+3}D_mQ_m\in\mathbf Z
\]

shows that the \(2\)-primary denominator of \(Q_m\) is also killed by

\[
2^{4m+3+v_2(D_m)}.
\]

Since

\[
v_2(D_m)=\lfloor\log_2m\rfloor
\le
\lfloor\log_2(2m-1)\rfloor,
\]

equation (5.2) follows.

Similarly,

\[
2^{6m}D_{2m-1}^2P_m\in\mathbf Z
\]

and

\[
2^{4m+3}D_{2m-1}^3P_m\in\mathbf Z.
\]

Hence the remaining \(2\)-primary denominator of
\(D_{2m-1}^2P_m\) is killed by

\[
2^{4m+3+v_2(D_{2m-1})}
=
2^{4m+3+\lfloor\log_2(2m-1)\rfloor}.
\]

This proves (5.3).

Finally the second expression inside the minimum in (5.1) is

\[
4m+O(\log m),
\]

and is smaller than \(6m\) for all sufficiently large \(m\). Hence (5.4). \(\square\)

---

# 6. Exact \(2\)-adic valuations of the Zudilin solutions

The next result is elementary and does not use the Gap Lemma.

## Lemma 6.1

For every \(m\ge0\),

\[
\boxed{
v_2(Q_m)=-4m+2s_2(m).
}
\tag{6.1}
\]

For every \(m\ge1\),

\[
\boxed{
v_2(P_m)=-4m+2s_2(m)-1.
}
\tag{6.2}
\]

### Proof

First note that

\[
\varphi(m)=20m^2-8m+1
\]

is odd for every \(m\).

Also

\[
C_m\equiv7\equiv1\pmod2,
\]

so \(C_m\) is odd.

Write

\[
L_m=(2m+1)^2(2m+2)^2\varphi(m),
\]

and

\[
R_m=(2m-1)^2(2m)^2\varphi(m+1).
\]

Then

\[
v_2(L_m)=2+2v_2(m+1),
\tag{6.3}
\]

and

\[
v_2(R_m)=2+2v_2(m).
\tag{6.4}
\]

We prove simultaneously that every nonzero solution under consideration has valuation

\[
v_2(z_m)=-4m+2s_2(m)+c,
\tag{6.5}
\]

where \(c=0\) for \(Q\) and \(c=-1\) for \(P\).

Assume the formula holds at \(m\) and \(m-1\).

The valuation of the central term \(C_mz_m\) is

\[
-4m+2s_2(m)+c.
\]

The valuation of \(R_mz_{m-1}\) is

\[
2+2v_2(m)
-4(m-1)+2s_2(m-1)+c.
\]

Subtracting the central-term valuation and using Lemma 3.1 gives

\[
\begin{aligned}
&2+2v_2(m)+4
+2(s_2(m-1)-s_2(m))\\
&=
6+2v_2(m)
+2(-1+v_2(m))\\
&=
4+4v_2(m)>0.
\end{aligned}
\]

Thus \(C_mz_m\) is the unique term of minimum \(2\)-adic valuation on the right side of the recurrence.

Therefore no \(2\)-adic cancellation occurs, and

\[
v_2(z_{m+1})
=
v_2(z_m)-v_2(L_m).
\]

Using (6.3),

\[
v_2(z_{m+1})
=
-4m+2s_2(m)+c
-2-2v_2(m+1).
\]

By Lemma 3.1 in its \(m+1\) form,

\[
s_2(m+1)=s_2(m)+1-v_2(m+1).
\]

Hence

\[
\begin{aligned}
v_2(z_{m+1})
&=
-4m-2+2s_2(m)-2v_2(m+1)+c\\
&=
-4(m+1)+2s_2(m+1)+c.
\end{aligned}
\]

The initial cases are

\[
v_2(Q_0)=0,
\]

\[
v_2(Q_1)=v_2(7/4)=-2
=-4+2s_2(1),
\]

and

\[
v_2(P_1)=v_2(13/8)=-3
=-4+2s_2(1)-1.
\]

For \(P\), the \(m=1\) recurrence has \(P_0=0\), so the absent second term causes no difficulty.

The induction is complete. \(\square\)

---

# 7. Zudilin's discrete Wronskian

Define

\[
W_m^Z
=
P_mQ_{m-1}-Q_mP_{m-1},
\qquad m\ge1.
\]

## Lemma 7.1

For every \(m\ge1\),

\[
\boxed{
W_m^Z
=
(-1)^{m-1}
\frac{\varphi(m)}
{8m^2(2m-1)^2}.
}
\tag{7.1}
\]

### Proof

For a recurrence

\[
L_mz_{m+1}=C_mz_m+R_mz_{m-1},
\]

the Wronskian of two solutions satisfies

\[
W_{m+1}=-\frac{R_m}{L_m}W_m.
\tag{7.2}
\]

Indeed,

\[
\begin{aligned}
W_{m+1}
&=
P_{m+1}Q_m-Q_{m+1}P_m\\
&=
\frac{R_m}{L_m}
(P_{m-1}Q_m-Q_{m-1}P_m)\\
&=
-\frac{R_m}{L_m}W_m.
\end{aligned}
\]

Now

\[
W_1^Z=P_1Q_0-Q_1P_0=\frac{13}{8}.
\]

Since

\[
\varphi(1)=13,
\]

formula (7.1) holds for \(m=1\).

The quotient of the claimed formula at \(m+1\) and \(m\) is

\[
-
\frac{
m^2(2m-1)^2\varphi(m+1)
}{
(m+1)^2(2m+1)^2\varphi(m)
},
\]

which is precisely

\[
-\frac{R_m}{L_m}.
\]

Therefore the formula follows by induction. \(\square\)

---

# 8. The Zudilin \(2\)-adic limit and its exact tail

Define

\[
R_m^Z=\frac{P_m}{Q_m}.
\]

## Lemma 8.1

For \(m\ge1\),

\[
v_2(R_m^Z-R_{m-1}^Z)
=
8m-5-4s_2(m)-4v_2(m).
\tag{8.1}
\]

### Proof

By Lemma 7.1,

\[
R_m^Z-R_{m-1}^Z
=
\frac{W_m^Z}{Q_mQ_{m-1}}.
\]

Because \(\varphi(m)\) and \(2m-1\) are odd,

\[
v_2(W_m^Z)
=
-3-2v_2(m).
\]

By Lemma 6.1,

\[
v_2(Q_m)
=
-4m+2s_2(m),
\]

and

\[
v_2(Q_{m-1})
=
-4(m-1)+2s_2(m-1).
\]

Using Lemma 3.1,

\[
s_2(m-1)=s_2(m)-1+v_2(m).
\]

Substitution gives (8.1). \(\square\)

## Lemma 8.2

The sequence \(R_m^Z\) converges in \(\mathbf Q_2\) to a limit, denoted

\[
\mathcal G_{Z,2}.
\]

Moreover

\[
\boxed{
v_2\left(
\mathcal G_{Z,2}-R_m^Z
\right)
=
8m-1-4s_2(m).
}
\tag{8.2}
\]

### Proof

Let

\[
w_m
=
8m-5-4s_2(m)-4v_2(m).
\]

Using Lemma 3.1,

\[
w_{m+1}-w_m
=
4+4v_2(m)>0.
\]

Hence

\[
w_m\to+\infty.
\]

Therefore

\[
\sum_{m\ge1}(R_m^Z-R_{m-1}^Z)
\]

converges in \(\mathbf Q_2\), proving existence of \(\mathcal G_{Z,2}\).

The first omitted increment in the tail beginning after index \(m\) has valuation

\[
w_{m+1}.
\]

Using

\[
s_2(m+1)=s_2(m)+1-v_2(m+1),
\]

we find

\[
w_{m+1}
=
8m-1-4s_2(m).
\]

All later increments have strictly larger valuation.

By the ultrametric inequality, the valuation of the whole tail equals the valuation of its unique first term. This proves (8.2). \(\square\)

---

# 9. The modular \(E\)-family Catalan recurrence

Define \(A_n,B_n\) by the common recurrence

\[
(n+1)^2u_{n+1}
=
(12n(n+1)+4)u_n
-
32n^2u_{n-1},
\tag{9.1}
\]

with

\[
(A_0,A_1)=(1,4),
\]

and

\[
(B_0,B_1)=(0,1).
\]

We import the following established properties.

## Imported Theorem E

For every \(n\ge0\),

\[
A_n\in\mathbf Z.
\]

For every \(n\ge0\),

\[
D_n^2B_n\in\mathbf Z.
\]

Furthermore,

\[
\frac{B_n}{A_n}\to\frac G2.
\]

The archimedean rates are

\[
\frac1n\log|A_n|\to\log8,
\tag{9.2}
\]

and

\[
\frac1n
\log\left|
\frac G2A_n-B_n
\right|
\to\log4.
\tag{9.3}
\]

Finally the exact Wronskian is

\[
\boxed{
A_nB_{n-1}-A_{n-1}B_n
=
-\frac{32^{n-1}}{n^2}.
}
\tag{9.4}
\]

---

# 10. Exact \(2\)-adic valuations of the modular \(E\)-row

## Lemma 10.1

For every \(n\ge0\),

\[
\boxed{
v_2(A_n)=2s_2(n).
}
\tag{10.1}
\]

For every \(n\ge1\),

\[
\boxed{
v_2(B_n)=2s_2(n)-2.
}
\tag{10.2}
\]

### Proof

Rewrite (9.1) as

\[
(n+1)^2u_{n+1}
=
4(3n(n+1)+1)u_n
-
32n^2u_{n-1}.
\]

Since \(n(n+1)\) is even,

\[
3n(n+1)+1
\]

is odd.

Suppose

\[
v_2(u_n)=2s_2(n)+c,
\]

and

\[
v_2(u_{n-1})=2s_2(n-1)+c.
\]

The first term on the right has valuation

\[
2+2s_2(n)+c.
\]

The second has valuation

\[
5+2v_2(n)+2s_2(n-1)+c.
\]

Subtracting the first valuation from the second and using Lemma 3.1 gives

\[
\begin{aligned}
&3+2v_2(n)
+2(s_2(n-1)-s_2(n))\\
&=
3+2v_2(n)+2(-1+v_2(n))\\
&=
1+4v_2(n)>0.
\end{aligned}
\]

Thus the first term is uniquely of minimal \(2\)-adic valuation.

Consequently

\[
v_2(u_{n+1})
=
2+2s_2(n)+c
-
2v_2(n+1).
\]

Use

\[
s_2(n+1)=s_2(n)+1-v_2(n+1)
\]

to obtain

\[
v_2(u_{n+1})
=
2s_2(n+1)+c.
\]

For \(A\), \(c=0\), since

\[
v_2(A_0)=0
\]

and

\[
v_2(A_1)=2.
\]

For \(B\), \(c=-2\), since

\[
v_2(B_1)=0.
\]

The \(B_0=0\) term causes no difficulty at the first induction step. \(\square\)

---

# 11. The modular \(E\)-row \(2\)-adic limit

Define

\[
R_n^E=\frac{2B_n}{A_n}.
\]

## Lemma 11.1

For every \(n\ge1\),

\[
v_2(R_n^E-R_{n-1}^E)
=
5n-2-4s_2(n)-4v_2(n).
\tag{11.1}
\]

### Proof

By the Wronskian (9.4),

\[
\frac{B_n}{A_n}
-
\frac{B_{n-1}}{A_{n-1}}
=
\frac{32^{n-1}}
{n^2A_nA_{n-1}}.
\]

Multiplying by \(2\),

\[
R_n^E-R_{n-1}^E
=
\frac{2\cdot32^{n-1}}
{n^2A_nA_{n-1}}.
\]

Now apply Lemma 10.1 and Lemma 3.1. \(\square\)

## Lemma 11.2

The sequence \(R_n^E\) converges in \(\mathbf Q_2\) to a limit

\[
\mathcal G_{E,2}.
\]

Furthermore,

\[
\boxed{
v_2\left(
\mathcal G_{E,2}-R_n^E
\right)
=
5n-1-4s_2(n).
}
\tag{11.2}
\]

In particular,

\[
\boxed{
v_2\left(
\mathcal G_{E,2}
-\frac{2B_{2m}}{A_{2m}}
\right)
=
10m-1-4s_2(m).
}
\tag{11.3}
\]

### Proof

The proof is identical to Lemma 8.2.

The successive-increment valuations in (11.1) are strictly increasing, and the first omitted increment after index \(n\) has valuation

\[
5n-1-4s_2(n).
\]

Since

\[
s_2(2m)=s_2(m),
\]

equation (11.3) follows. \(\square\)

---

# 12. The sole unresolved arithmetic identification

## Gap Hypothesis 12.1

The two \(2\)-adic Catalan limits coincide:

\[
\boxed{
\mathcal G_{Z,2}
=
\mathcal G_{E,2}.
}
\tag{12.1}
\]

Denote their common value, if the hypothesis holds, by

\[
\mathcal G_2.
\]

This is the only unproved hypothesis in the headline worthiness theorem below.

---

# 13. Equivalence with the exact cross-determinant congruence

## Proposition 13.1

Assume Gap Hypothesis 12.1.

Then for every \(m\ge1\),

\[
\boxed{
v_2\left(
\frac{P_m}{Q_m}
-
\frac{2B_{2m}}{A_{2m}}
\right)
=
8m-1-4s_2(m).
}
\tag{13.1}
\]

### Proof

By Lemma 8.2,

\[
v_2\left(
\mathcal G_2-\frac{P_m}{Q_m}
\right)
=
8m-1-4s_2(m).
\]

By Lemma 11.2,

\[
v_2\left(
\mathcal G_2-\frac{2B_{2m}}{A_{2m}}
\right)
=
10m-1-4s_2(m).
\]

The second valuation is strictly larger.

Therefore the two summands in

\[
\frac{P_m}{Q_m}
-\frac{2B_{2m}}{A_{2m}}
=
\left(
\frac{P_m}{Q_m}-\mathcal G_2
\right)
+
\left(
\mathcal G_2-\frac{2B_{2m}}{A_{2m}}
\right)
\]

have distinct valuations.

In a nonarchimedean valued field, the valuation of a sum of two terms with unequal valuations equals the smaller valuation.

Hence (13.1). \(\square\)

## Theorem 13.2: exact Plücker valuation

Assume Gap Hypothesis 12.1.

Then for every \(m\ge1\),

\[
\boxed{
v_2\left(
P_mA_{2m}-2B_{2m}Q_m
\right)
=
4m-1.
}
\tag{13.2}
\]

### Proof

Factor

\[
P_mA_{2m}-2B_{2m}Q_m
=
Q_mA_{2m}
\left(
\frac{P_m}{Q_m}
-\frac{2B_{2m}}{A_{2m}}
\right).
\]

By Lemma 6.1,

\[
v_2(Q_m)
=
-4m+2s_2(m).
\]

By Lemma 10.1,

\[
v_2(A_{2m})
=
2s_2(2m)
=
2s_2(m).
\]

By Proposition 13.1,

\[
v_2\left(
\frac{P_m}{Q_m}
-\frac{2B_{2m}}{A_{2m}}
\right)
=
8m-1-4s_2(m).
\]

Adding,

\[
\begin{aligned}
v_2(
P_mA_{2m}-2B_{2m}Q_m
)
&=
-4m+4s_2(m)\\
&\qquad+
8m-1-4s_2(m)\\
&=
4m-1.
\end{aligned}
\]

This proves (13.2). \(\square\)

## Remark 13.3

Conversely, if (13.2) holds for all sufficiently large \(m\), then

\[
v_2\left(
\frac{P_m}{Q_m}
-\frac{2B_{2m}}{A_{2m}}
\right)
\longrightarrow+\infty.
\]

Since both rational sequences already have \(2\)-adic limits, their limits must coincide.

Thus the Gap Hypothesis and the asymptotic form of the cross-determinant theorem are equivalent.

---

# 14. The common LCM-square at index \(3n\) and \(6n\)

## Lemma 14.1

For every \(n\ge1\),

\[
D_{6n}=D_{6n-1}.
\tag{14.1}
\]

### Proof

The integer \(6n\) is divisible by both \(2\) and \(3\), and hence is not a prime power.

The least common multiple \(D_N\) changes from \(D_{N-1}\) only when \(N\) is a prime power.

Therefore

\[
D_{6n}=D_{6n-1}.
\]

\(\square\)

Set

\[
S_n=D_{6n}^2.
\tag{14.2}
\]

By the prime number theorem,

\[
\boxed{
\frac1n\log S_n\to12.
}
\tag{14.3}
\]

---

# 15. Two integer Catalan rows

We now construct the two rows used in the improved approximation.

## Definition 15.1: modular \(E\)-row

Set

\[
X_{1,n}=S_nA_{6n},
\tag{15.1}
\]

\[
Y_{1,n}=2S_nB_{6n}.
\tag{15.2}
\]

By Imported Theorem E,

\[
X_{1,n},Y_{1,n}\in\mathbf Z.
\]

Define its Catalan linear form

\[
\lambda_{1,n}
=
X_{1,n}G-Y_{1,n}.
\tag{15.3}
\]

## Definition 15.2: Zudilin row

Set

\[
X_{2,n}
=
2^{e_{3n}}S_nQ_{3n},
\tag{15.4}
\]

\[
Y_{2,n}
=
2^{e_{3n}}S_nP_{3n}.
\tag{15.5}
\]

Because

\[
S_n=D_{6n-1}^2,
\]

Lemma 5.1 gives

\[
X_{2,n},Y_{2,n}\in\mathbf Z.
\]

Define

\[
\lambda_{2,n}
=
X_{2,n}G-Y_{2,n}.
\tag{15.6}
\]

Both first coordinates are visibly divisible by \(S_n\).

---

# 16. Archimedean rates of the two rows

Define

\[
A_E=12+18\log2,
\tag{16.1}
\]

\[
E_E=12+12\log2,
\tag{16.2}
\]

\[
A_Z=12+12\log2+15\log\phi,
\tag{16.3}
\]

\[
E_Z=12+12\log2-15\log\phi.
\tag{16.4}
\]

## Lemma 16.1

As \(n\to\infty\),

\[
\log|X_{1,n}|=A_E n+o(n),
\tag{16.5}
\]

\[
\log|Y_{1,n}|=A_E n+o(n),
\tag{16.6}
\]

\[
\log|\lambda_{1,n}|=E_E n+o(n).
\tag{16.7}
\]

Also,

\[
\log|X_{2,n}|=A_Z n+o(n),
\tag{16.8}
\]

\[
\log|Y_{2,n}|=A_Z n+o(n),
\tag{16.9}
\]

and

\[
\log|\lambda_{2,n}|=E_Z n+o(n).
\tag{16.10}
\]

### Proof

For row \(1\), Imported Theorem E gives

\[
\log|A_{6n}|
=
6n\log8+o(n),
\]

and

\[
\log|GA_{6n}-2B_{6n}|
=
6n\log4+o(n).
\]

Together with

\[
\log S_n=12n+o(n),
\]

this gives (16.5) and (16.7).

Since

\[
2B_{6n}/A_{6n}\to G,
\]

the numerator \(Y_{1,n}\) has the same leading exponential rate as \(X_{1,n}\), proving (16.6).

For row \(2\),

\[
e_{3n}=12n+o(n),
\]

so

\[
e_{3n}\log2
=
12n\log2+o(n).
\]

Imported Theorem Z gives

\[
\log|Q_{3n}|=15n\log\phi+o(n),
\]

and

\[
\log|Q_{3n}G-P_{3n}|
=
-15n\log\phi+o(n).
\]

Combining with \(\log S_n=12n+o(n)\) proves (16.8) and (16.10).

The limit \(P_{3n}/Q_{3n}\to G\) gives (16.9). \(\square\)

---

# 17. The crossed determinant has a strict dominant term

Define

\[
\mathcal D_n
=
X_{1,n}Y_{2,n}-X_{2,n}Y_{1,n}.
\tag{17.1}
\]

Using

\[
Y_{i,n}=GX_{i,n}-\lambda_{i,n},
\]

we have

\[
\mathcal D_n
=
X_{2,n}\lambda_{1,n}
-
X_{1,n}\lambda_{2,n}.
\tag{17.2}
\]

The first term has exponential rate

\[
A_Z+E_E.
\]

The second has rate

\[
A_E+E_Z.
\]

Their difference is

\[
\begin{aligned}
&(A_Z+E_E)-(A_E+E_Z)\\
&=
30\log\phi-6\log2.
\end{aligned}
\tag{17.3}
\]

This is positive because

\[
30\log\phi>6\log2
\]

is equivalent to

\[
\phi^5>2,
\]

and

\[
\phi^5=5\phi+3>2.
\]

Therefore

\[
\boxed{
\log|\mathcal D_n|
=
(A_Z+E_E)n+o(n).
}
\tag{17.4}
\]

In particular the two source rows are linearly independent for all sufficiently large \(n\).

---

# 18. The extra \(2\)-adic Plücker divisor

Define the first coordinates after removing the common LCM-square:

\[
a_{1,n}
=
\frac{X_{1,n}}{S_n}
=
A_{6n},
\tag{18.1}
\]

and

\[
a_{2,n}
=
\frac{X_{2,n}}{S_n}
=
2^{e_{3n}}Q_{3n}.
\tag{18.2}
\]

Both are integers.

Define the mixed minor

\[
h_n
=
a_{1,n}Y_{2,n}
-
a_{2,n}Y_{1,n}.
\tag{18.3}
\]

## Lemma 18.1

Assume Gap Hypothesis 12.1.

Then

\[
2^{24n}\mid h_n
\]

for every \(n\ge1\).

### Proof

From the definitions,

\[
\begin{aligned}
h_n
&=
A_{6n}
\left(
2^{e_{3n}}S_nP_{3n}
\right)
-
2^{e_{3n}}Q_{3n}
\left(
2S_nB_{6n}
\right)\\
&=
2^{e_{3n}}S_n
\left(
P_{3n}A_{6n}
-
2B_{6n}Q_{3n}
\right).
\end{aligned}
\]

By Theorem 13.2 with \(m=3n\),

\[
v_2
\left(
P_{3n}A_{6n}
-
2B_{6n}Q_{3n}
\right)
=
12n-1.
\]

Also

\[
e_{3n}\ge12n+1.
\]

Therefore

\[
v_2(h_n)
\ge
(12n+1)+(12n-1)
=
24n.
\]

The nonnegative contribution \(v_2(S_n)\) is not even needed.

Thus

\[
2^{24n}\mid h_n.
\]

\(\square\)

Define

\[
T_n=2^{24n}.
\tag{18.4}
\]

Then

\[
\boxed{
T_n\mid h_n.
}
\tag{18.5}
\]

Moreover

\[
\boxed{
\frac1n\log T_n=24\log2.
}
\tag{18.6}
\]

---

# 19. The double-congruence coefficient lattice

Put

\[
M_n=S_nT_n.
\tag{19.1}
\]

Define

\[
K_n
=
\left\{
(c_1,c_2)\in\mathbf Z^2:
\begin{array}{l}
a_{1,n}c_1+a_{2,n}c_2\equiv0\pmod{T_n},\\[1mm]
Y_{1,n}c_1+Y_{2,n}c_2\equiv0\pmod{S_nT_n}
\end{array}
\right\}.
\tag{19.2}
\]

For \(c=(c_1,c_2)\in K_n\), define

\[
q_n(c)
=
\frac{c_1X_{1,n}+c_2X_{2,n}}{M_n},
\tag{19.3}
\]

and

\[
p_n(c)
=
\frac{c_1Y_{1,n}+c_2Y_{2,n}}{M_n}.
\tag{19.4}
\]

These are integers.

Indeed,

\[
c_1X_{1,n}+c_2X_{2,n}
=
S_n
(c_1a_{1,n}+c_2a_{2,n}),
\]

and the first congruence in (19.2) makes this divisible by \(S_nT_n=M_n\).

The second congruence gives integrality of \(p_n(c)\).

Furthermore,

\[
q_n(c)G-p_n(c)
=
\frac{
c_1\lambda_{1,n}
+c_2\lambda_{2,n}
}{M_n}.
\tag{19.5}
\]

---

# 20. Exact index of the double-congruence lattice

## Lemma 20.1

Let, temporarily,

\[
S,T\ge1,
\]

and let

\[
a_1,a_2,y_1,y_2\in\mathbf Z.
\]

Define

\[
K
=
\left\{
(c_1,c_2)\in\mathbf Z^2:
\begin{array}{l}
a_1c_1+a_2c_2\equiv0\pmod T,\\
y_1c_1+y_2c_2\equiv0\pmod{ST}
\end{array}
\right\}.
\]

Put

\[
h=a_1y_2-a_2y_1.
\]

Then

\[
\boxed{
[\mathbf Z^2:K]
=
\frac{ST^2}
{
\gcd(
h,\,
Ty_1,\,
Ty_2,\,
STa_1,\,
STa_2,\,
ST^2
)
}.
}
\tag{20.1}
\]

### Proof

Consider the homomorphism

\[
\Psi:
\mathbf Z^2
\longrightarrow
\mathbf Z/T\mathbf Z
\oplus
\mathbf Z/(ST)\mathbf Z
\]

given by

\[
(c_1,c_2)
\longmapsto
(
a_1c_1+a_2c_2,\,
y_1c_1+y_2c_2
).
\]

Then

\[
K=\ker\Psi,
\]

so

\[
[\mathbf Z^2:K]
=
|\operatorname{im}\Psi|.
\tag{20.2}
\]

The finite abelian group

\[
\operatorname{coker}\Psi
\]

has the presentation matrix

\[
\begin{pmatrix}
a_1&a_2&T&0\\
y_1&y_2&0&ST
\end{pmatrix}.
\]

Since this is a rank-two presentation of a finite abelian group, the order of the cokernel equals the greatest common divisor of its \(2\times2\) minors.

Those minors are, up to sign,

\[
h,\,
Ty_1,\,
Ty_2,\,
STa_1,\,
STa_2,\,
ST^2.
\]

Therefore

\[
|\operatorname{coker}\Psi|
=
\gcd(
h,Ty_1,Ty_2,STa_1,STa_2,ST^2
).
\]

The target group has order

\[
ST^2.
\]

Hence

\[
|\operatorname{im}\Psi|
=
\frac{ST^2}
{|\operatorname{coker}\Psi|},
\]

which is (20.1). \(\square\)

## Corollary 20.2

If

\[
T\mid h,
\]

then

\[
\boxed{
[\mathbf Z^2:K]\le ST.
}
\tag{20.3}
\]

### Proof

Every integer in the gcd in the denominator of (20.1) is divisible by \(T\):

- \(h\) by hypothesis;
- \(Ty_1,Ty_2\) trivially;
- \(STa_1,STa_2\) trivially;
- \(ST^2\) trivially.

Hence the gcd is at least \(T\), and

\[
[\mathbf Z^2:K]
\le
\frac{ST^2}{T}
=
ST.
\]

\(\square\)

Applying this to \(K_n\) gives

\[
[\mathbf Z^2:K_n]\le M_n.
\tag{20.4}
\]

---

# 21. Lattice thinning removes every residual-gcd issue

The previous corollary gives an upper bound on the covolume. For the two-successive-minima theorem it is convenient to use a sublattice whose covolume has exactly the same exponential scale as \(M_n\).

## Lemma 21.1: covolume normalization

Let \(K\subseteq\mathbf Z^2\) be a rank-two lattice with

\[
d=[\mathbf Z^2:K]\le M.
\]

Then there exists a sublattice

\[
L\subseteq K
\]

such that

\[
M\le
[\mathbf Z^2:L]
<
2M.
\tag{21.1}
\]

### Proof

Choose a lattice basis \(b_1,b_2\) of \(K\).

Set

\[
k=\left\lceil\frac Md\right\rceil.
\]

Define

\[
L=\mathbf Z(kb_1)+\mathbf Zb_2.
\]

Then

\[
[K:L]=k.
\]

Therefore

\[
[\mathbf Z^2:L]=kd.
\]

By the definition of \(k\),

\[
kd\ge M.
\]

Also

\[
k<\frac Md+1,
\]

hence

\[
kd<M+d\le2M.
\]

This proves (21.1). \(\square\)

Apply this lemma to \(K_n\) with \(M=M_n\).

Choose once and for all a sublattice

\[
L_n\subseteq K_n
\]

satisfying

\[
M_n
\le
d_n:=[\mathbf Z^2:L_n]
<
2M_n.
\tag{21.2}
\]

Every vector in \(L_n\) still satisfies both divisibility conditions.

Hence for \(c\in L_n\), the integers \(q_n(c),p_n(c)\) in (19.3)-(19.4) are still well defined.

Moreover,

\[
\log d_n
=
\log M_n+O(1).
\tag{21.3}
\]

This lemma is important: no hypothesis about an unknown residual gcd is needed.

---

# 22. General two-successive-minima theorem with a prescribed division modulus

We now state the abstract theorem in exactly the form needed here.

## Theorem 22.1: balanced two-row selection

Let \(\alpha\in\mathbf R\).

For each sufficiently large \(n\), suppose we have two integer rows

\[
(X_{1,n},Y_{1,n}),
\qquad
(X_{2,n},Y_{2,n}),
\]

and define

\[
\lambda_{i,n}
=
X_{i,n}\alpha-Y_{i,n}.
\]

Assume real constants \(A_1,E_1,A_2,E_2\) satisfy

\[
\log|X_{i,n}|=A_i n+o(n),
\]

\[
\log|Y_{i,n}|=A_i n+o(n),
\]

and

\[
\log|\lambda_{i,n}|=E_i n+o(n).
\]

Assume the strict crossed gap

\[
A_2+E_1>A_1+E_2.
\tag{22.1}
\]

Let \(M_n\) be positive integers such that

\[
\frac1n\log M_n\to\sigma.
\tag{22.2}
\]

Suppose \(L_n\subseteq\mathbf Z^2\) is a rank-two lattice such that:

1. for every \(c=(c_1,c_2)\in L_n\),
   \[
   M_n\mid c_1X_{1,n}+c_2X_{2,n},
   \]
   and
   \[
   M_n\mid c_1Y_{1,n}+c_2Y_{2,n};
   \]

2. its covolume satisfies
   \[
   \log[\mathbf Z^2:L_n]
   =
   \log M_n+o(n).
   \tag{22.3}
   \]

Define

\[
x=
\frac{\sigma+E_2-E_1}{2},
\tag{22.4}
\]

\[
H
=
A_2-x,
\tag{22.5}
\]

and

\[
F
=
x+E_1-\sigma.
\tag{22.6}
\]

Assume

\[
H>0,
\qquad
F>0.
\tag{22.7}
\]

Then there exists, for every sufficiently large \(n\), a vector

\[
c_n\in L_n
\]

such that, with

\[
q_n
=
\frac{
c_{1,n}X_{1,n}
+
c_{2,n}X_{2,n}
}{M_n},
\]

\[
p_n
=
\frac{
c_{1,n}Y_{1,n}
+
c_{2,n}Y_{2,n}
}{M_n},
\]

we have

\[
q_n\ne0,
\]

\[
q_n\alpha-p_n\ne0,
\]

\[
\log|q_n|
\ge
Hn-o(n),
\tag{22.8}
\]

and

\[
\log|q_n\alpha-p_n|
\le
Fn+o(n).
\tag{22.9}
\]

Consequently

\[
\boxed{
\delta(q,p)
\ge
1-\frac FH.
}
\tag{22.10}
\]

### Proof

Put

\[
d_n=[\mathbf Z^2:L_n].
\]

Write

\[
\kappa_n=\frac1n\log d_n,
\qquad
\sigma_n=\frac1n\log M_n.
\]

By hypothesis,

\[
\kappa_n-\sigma_n\to0.
\tag{22.11}
\]

Define

\[
x_n
=
\frac{\kappa_n+E_2-E_1}{2}.
\tag{22.12}
\]

Then

\[
x_n\to x.
\]

Define

\[
H_n
=
\kappa_n-x_n+A_2-\sigma_n,
\tag{22.13}
\]

and

\[
F_n
=
x_n+E_1-\sigma_n.
\tag{22.14}
\]

Then

\[
H_n\to H,
\qquad
F_n\to F.
\tag{22.15}
\]

Also

\[
H_n-F_n=A_2-E_2.
\tag{22.16}
\]

Because \(H,F>0\), both \(H_n,F_n\) are bounded below by a positive constant for all sufficiently large \(n\).

Consider the centrally symmetric rectangle

\[
\mathcal C_n
=
\left\{
(u,v)\in\mathbf R^2:
|u|\le e^{x_nn},
\quad
|v|\le e^{(\kappa_n-x_n)n}
\right\}.
\tag{22.17}
\]

Its area is

\[
4e^{\kappa_nn}=4d_n.
\]

Let

\[
\mu_{1,n}\le\mu_{2,n}
\]

be the successive minima of \(L_n\) relative to \(\mathcal C_n\).

Minkowski's second theorem in dimension two gives

\[
\mu_{1,n}\mu_{2,n}\le1.
\tag{22.18}
\]

In particular,

\[
\mu_{1,n}\le1.
\]

Choose independent lattice vectors

\[
b_1,b_2\in L_n
\]

corresponding to the two successive minima.

Since \(b_1,b_2\) are independent lattice vectors,

\[
|\det(b_1,b_2)|
\]

is a positive integer multiple of \(d_n\).

On the other hand, using the coordinate bounds in the dilated rectangles,

\[
|\det(b_1,b_2)|
\le
2\mu_{1,n}\mu_{2,n}d_n
\le2d_n.
\]

Therefore

\[
d_n
\le
|\det(b_1,b_2)|
\le
2d_n,
\]

and hence

\[
\log|\det(b_1,b_2)|
=
\log d_n+O(1).
\tag{22.19}
\]

Let

\[
q_i
=
\frac{
b_{i,1}X_{1,n}
+
b_{i,2}X_{2,n}
}{M_n},
\]

and

\[
\ell_i
=
q_i\alpha
-
\frac{
b_{i,1}Y_{1,n}
+
b_{i,2}Y_{2,n}
}{M_n}.
\]

Thus

\[
\ell_i
=
\frac{
b_{i,1}\lambda_{1,n}
+
b_{i,2}\lambda_{2,n}
}{M_n}.
\]

Choose a sequence \(\varepsilon_n\to0\) that dominates every normalized \(o(n)\) error occurring in the rate assumptions.

Write

\[
r_n
=
-\frac1n\log\mu_{1,n}\ge0.
\]

Since

\[
\mu_{2,n}\le\mu_{1,n}^{-1},
\]

the coordinates of \(b_1\) have an extra factor \(e^{-r_nn}\), while those of \(b_2\) have at worst an extra factor \(e^{r_nn}\).

By the definition of \(x_n\), the two possible contributions to each \(\ell_i\) have the same exponential rate.

By the crossed-gap condition (22.1), the \(X_2\)-contribution dominates the \(X_1\)-contribution in the corresponding \(q_i\) bounds.

Thus

\[
|q_1|
\le
e^{(H_n-r_n+O(\varepsilon_n))n},
\tag{22.20}
\]

\[
|\ell_1|
\le
e^{(F_n-r_n+O(\varepsilon_n))n},
\tag{22.21}
\]

\[
|q_2|
\le
e^{(H_n+r_n+O(\varepsilon_n))n},
\tag{22.22}
\]

and

\[
|\ell_2|
\le
e^{(F_n+r_n+O(\varepsilon_n))n}.
\tag{22.23}
\]

Now define the determinant of the two divided output rows:

\[
\Delta_n'
=
q_1p_2-q_2p_1.
\]

Using bilinearity,

\[
\Delta_n'
=
\frac{
\det(b_1,b_2)
\left(
X_{1,n}Y_{2,n}
-
X_{2,n}Y_{1,n}
\right)
}{
M_n^2
}.
\tag{22.24}
\]

The source determinant has rate

\[
(A_2+E_1)n+o(n)
\]

by the crossed-gap hypothesis.

Combining this with (22.19), (22.11), and (22.24),

\[
\log|\Delta_n'|
=
(H_n+F_n)n+o(n).
\tag{22.25}
\]

We now select a nonzero output.

### Case 1: \(r_n=o(1)\)

Then (22.20)-(22.23) place both rows near the target exponents \(H_n,F_n\).

Equation (22.25) forces at least one of \(|q_1|,|q_2|\) to satisfy

\[
\log|q_i|
\ge
H_nn-o(n).
\]

Choose such a row.

If its linear form is nonzero, we are done.

If its linear form vanishes, add or subtract the other row, choosing the sign for which the first coordinates do not cancel.

The two linear forms cannot both vanish, because otherwise

\[
\Delta_n'
=
q_2\ell_1-q_1\ell_2
\]

would vanish, contradicting (22.25).

Thus this modification gives a row with nonzero first coordinate and nonzero linear form, with the same exponential bounds.

### Case 2: \(r_n\) is bounded away from \(0\) and \(\ell_1\ne0\)

Choose \(m_n\in\mathbf Z\) such that

\[
0<
|\ell_2-m_n\ell_1|
\le
\frac32|\ell_1|.
\tag{22.26}
\]

Set

\[
q'=q_2-m_nq_1,
\]

and

\[
\ell'=\ell_2-m_n\ell_1.
\]

Since

\[
\Delta_n'
=
q_2\ell_1-q_1\ell_2,
\]

we obtain

\[
q'
=
\frac{\Delta_n'}{\ell_1}
+
q_1\frac{\ell'}{\ell_1}.
\tag{22.27}
\]

Let

\[
a_n=\frac1n\log|\ell_1|.
\]

Then

\[
a_n
\le
F_n-r_n+o(1).
\]

The first term on the right of (22.27) has logarithmic rate

\[
H_n+F_n-a_n,
\]

whereas the second has rate at most

\[
H_n-r_n.
\]

Because

\[
a_n
\le
F_n-r_n+o(1),
\]

the first term dominates exponentially.

Thus

\[
\frac1n\log|q'|
=
H_n+F_n-a_n+o(1),
\]

and

\[
\log|\ell'|
\le
a_nn+O(1).
\]

The function

\[
a\longmapsto
\frac{a}{H_n+F_n-a}
\]

is increasing on the relevant interval. Therefore

\[
\frac{\log|\ell'|}{\log|q'|}
\le
\frac{F_n-r_n+o(1)}
{H_n+r_n-o(1)}
\le
\frac{F_n}{H_n}+o(1).
\]

Also

\[
\log|q'|
\ge
H_nn-o(n).
\]

### Case 3: \(\ell_1=0\)

Then (22.25) implies

\[
q_1\ne0
\]

and

\[
\ell_2\ne0.
\]

Choose a constant \(C\) larger than all relevant bounded exponential rates and satisfying

\[
\frac{B_\ell}{C}
<
\inf_{n\gg1}\frac{F_n}{H_n},
\]

where \(B_\ell\) is any fixed eventual exponential upper bound for \(|\ell_2|\).

Put

\[
N_n=\lceil e^{Cn}\rceil
\]

and replace \(b_2\) by

\[
b_2+N_nb_1.
\]

Its linear form remains exactly

\[
\ell_2\ne0
\]

because \(\ell_1=0\).

Its first coordinate has size

\[
e^{Cn+o(n)}.
\]

Since \(C>H\), the required height lower bound holds, and the ratio of the linear-form logarithm to the height logarithm is smaller than \(F/H\).

Thus in every case we obtain an admissible row satisfying (22.8)-(22.9).

Finally,

\[
-\log\left|\alpha-\frac{p_n}{q_n}\right|
=
\log|q_n|-\log|q_n\alpha-p_n|.
\]

Therefore

\[
\delta(q,p)
\ge
1-\frac FH.
\]

This proves the theorem. \(\square\)

---

# 23. Application to Catalan's constant

We now apply Theorem 22.1.

Take

\[
\alpha=G.
\]

Use row \(1\) for the modular \(E\)-family and row \(2\) for Zudilin.

By Section 16,

\[
A_1=A_E=12+18\log2,
\]

\[
E_1=E_E=12+12\log2,
\]

\[
A_2=A_Z=12+12\log2+15\log\phi,
\]

and

\[
E_2=E_Z=12+12\log2-15\log\phi.
\]

The total division modulus is

\[
M_n=S_nT_n.
\]

Hence

\[
\begin{aligned}
\sigma
&=
\lim_{n\to\infty}
\frac1n\log M_n\\
&=
12+24\log2.
\end{aligned}
\tag{23.1}
\]

The crossed gap is

\[
A_2+E_1-A_1-E_2
=
30\log\phi-6\log2>0.
\]

By Sections 19-21 we have a lattice \(L_n\) satisfying both divisibility conditions and

\[
\log[\mathbf Z^2:L_n]
=
\log M_n+O(1).
\]

Thus every hypothesis of Theorem 22.1 is satisfied once Gap Hypothesis 12.1 is assumed.

Compute

\[
x
=
\frac{\sigma+E_2-E_1}{2}.
\]

Since

\[
E_2-E_1=-15\log\phi,
\]

we obtain

\[
x
=
6+12\log2-\frac{15}{2}\log\phi.
\tag{23.2}
\]

Therefore

\[
\begin{aligned}
H
&=
A_2-x\\
&=
12+12\log2+15\log\phi\\
&\qquad
-
\left(
6+12\log2-\frac{15}{2}\log\phi
\right)\\
&=
\boxed{
6+\frac{45}{2}\log\phi.
}
\end{aligned}
\tag{23.3}
\]

Similarly,

\[
\begin{aligned}
F
&=
x+E_1-\sigma\\
&=
6+12\log2-\frac{15}{2}\log\phi\\
&\qquad
+12+12\log2
-(12+24\log2)\\
&=
\boxed{
6-\frac{15}{2}\log\phi.
}
\end{aligned}
\tag{23.4}
\]

Since

\[
\phi<2
\]

and

\[
\log2<\frac45,
\]

we have

\[
\log\phi<\frac45,
\]

hence

\[
F>0.
\]

Clearly

\[
H>0.
\]

Thus Theorem 22.1 applies.

---

# 24. Headline Catalan worthiness theorem

## Theorem 24.1: conditional improved Catalan construction

Assume Gap Hypothesis 12.1, equivalently the exact \(2\)-adic cross-determinant theorem

\[
v_2(P_mA_{2m}-2B_{2m}Q_m)=4m-1
\]

for all \(m\ge1\).

Then there exists an admissible sequence

\[
(q_n,p_n)\in\mathbf Z^2
\]

approximating Catalan's constant \(G\) such that

\[
\boxed{
\delta(q,p)
\ge
\frac{30\log\phi}
{6+\frac{45}{2}\log\phi}.
}
\tag{24.1}
\]

Numerically,

\[
\boxed{
\delta(q,p)
\ge
0.8579144524736175393706930538509289\ldots.
}
\tag{24.2}
\]

### Proof

From Theorem 22.1,

\[
\delta(q,p)\ge1-\frac FH.
\]

By (23.3)-(23.4),

\[
H-F
=
30\log\phi.
\]

Therefore

\[
1-\frac FH
=
\frac{H-F}{H}
=
\frac{30\log\phi}
{6+\frac{45}{2}\log\phi}.
\]

This is (24.1).

The decimal value is direct numerical evaluation.

Admissibility, including

\[
q_n\ne0,
\qquad
q_nG-p_n\ne0,
\qquad
|q_n|\to\infty,
\]

is part of Theorem 22.1. \(\square\)

---

# 25. Comparison with the previous full-LCM construction

The previous Zudilin-Nesterenko full-LCM-square construction proves the unconditional bound

\[
\delta_{\mathrm{old}}
\ge
0.6588705072298054107388708602\ldots.
\]

The present conditional theorem gives

\[
\delta_{\mathrm{new}}
\ge
0.8579144524736175393706930539\ldots.
\]

Thus the absolute increase is

\[
0.1990439452438121\ldots.
\]

Measured as a fraction of the old remaining distance to the irrationality threshold \(1\),

\[
\frac{
\delta_{\mathrm{new}}-\delta_{\mathrm{old}}
}{
1-\delta_{\mathrm{old}}
}
\approx0.5835.
\]

Thus the new construction removes approximately \(58\%\) of the previous gap to \(1\).

No irrationality conclusion follows because

\[
0.8579144524\ldots<1.
\]

---

# 26. Interpretation in adelic Layer C

The arithmetic mechanism is not merely a better denominator estimate for either individual row.

The two rows have different real analytic behavior:

- Zudilin gives a hypergeometric Catalan realization with dominant/subdominant ratio controlled by \(\phi^{\pm5m}\);
- the modular \(E\)-family gives an elliptic realization with characteristic scales \(8^n\) and \(4^n\).

Nevertheless the Gap Hypothesis says that the two rational approximants converge to the same finite-place extension coordinate in \(\mathbf Q_2\).

The exact consequence is the exterior-power congruence

\[
v_2
\left(
P_mA_{2m}-2B_{2m}Q_m
\right)
=
4m-1.
\]

At the matched indices \(m=3n\) and \(2m=6n\), this produces a Plücker divisor of exponential size

\[
2^{24n}.
\]

The finite-place gain therefore lives not in either individual denominator lattice but in the determinant of the two realizations.

This is naturally described as a rank-two exterior-power invariant of the combined adelic realization.

---

# 27. Exact dependency graph for formal verification

A formal proof assistant or autoformalizer can organize the result as follows.

## Imported statements

The proof imports only:

**Z1.** The Zudilin recurrence (4.1) and initial conditions.

**Z2.** Zudilin's denominator statements in Imported Theorem Z.

**Z3.** Zudilin's archimedean rates and Catalan limit.

**E1.** The modular \(E\)-recurrence (9.1) and initial conditions.

**E2.** The all-\(n\) arithmetic statements

\[
A_n\in\mathbf Z,
\qquad
D_n^2B_n\in\mathbf Z.
\]

**E3.** The modular \(E\)-family Catalan limit and rates

\[
A_n\sim_{\exp}8^n,
\qquad
(G/2)A_n-B_n\sim_{\exp}4^n.
\]

**E4.** The exact Wronskian (9.4).

**PNT.**
\[
\log D_N=N+o(N).
\]

**MINK.** Minkowski's second theorem in dimension two.

## Proved internally

From these inputs the document proves:

1. binary digit identities;
2. exact \(v_2(Q_m)\);
3. exact \(v_2(P_m)\);
4. exact Zudilin Wronskian;
5. exact Zudilin \(2\)-adic tail;
6. exact \(v_2(A_n)\);
7. exact \(v_2(B_n)\);
8. exact modular-\(E\) \(2\)-adic tail;
9. equivalence of the common-\(2\)-adic-limit statement and the cross congruence;
10. the common \(D_{6n}^2\) normalization;
11. all archimedean row rates;
12. strict crossed dominance;
13. the \(2^{24n}\) Plücker divisibility from the Gap Lemma;
14. exact double-congruence lattice index;
15. lattice thinning to covolume \(M_n\);
16. the generalized two-successive-minima theorem;
17. the final worthiness constant.

## Sole unresolved input

The only new arithmetic input not proved in this note is

\[
\boxed{
\mathcal G_{Z,2}=\mathcal G_{E,2}.
}
\]

Equivalently:

\[
\boxed{
v_2(P_mA_{2m}-2B_{2m}Q_m)=4m-1.
}
\]

Once either formulation is proved, Theorem 24.1 is unconditional.

---

# 28. Evidence for the Gap Lemma

The following evidence should not be used as part of the formal proof.

Exact rational computation has been performed for

\[
1\le m\le100
\]

and gives, without exception,

\[
v_2(P_mA_{2m}-2B_{2m}Q_m)=4m-1.
\]

Moreover Sections 8 and 11 prove independently that the two rational sequences have \(2\)-adic limits with exact tails

\[
v_2\left(
\mathcal G_{Z,2}-\frac{P_m}{Q_m}
\right)
=
8m-1-4s_2(m)
\]

and

\[
v_2\left(
\mathcal G_{E,2}-\frac{2B_{2m}}{A_{2m}}
\right)
=
10m-1-4s_2(m).
\]

Thus the entire observed cross-congruence is forced once the equality of the two limits is known.

This reduces the gap from an all-\(m\) congruence family to one equality of \(2\)-adic constants.

---

# 29. Warning concerning one attempted proof of the Gap Lemma

An attempted argument through the Rivoal-Beukers Padé description must not be accepted without an additional uniform estimate.

The problematic step is the use of Beukers's Padé approximation theorem at moving arguments

\[
x_m=\frac12-m.
\]

A theorem giving strong \(2\)-adic approximation for each fixed rational \(x\) does not automatically yield a sufficiently strong estimate after \(x\) varies with the Padé degree \(m\).

In particular, one must estimate the **normalized Padé error after division by the moving denominator polynomial**.

The previously suggested shortcut did not establish that estimate.

Therefore the following chain must not be used without repair:

\[
\text{Rivoal moving Padé value}
\stackrel{\text{unproved}}{=}
\Theta_2(1/2)
\stackrel{}=
\text{modular \(E\) \(2\)-adic limit}.
\]

This is the precise gap.

---

# 30. Plausible routes to close the Gap Lemma

The gap can be attacked in several independent ways.

### Route A: direct tensor-recurrence proof

The four products

\[
P_mA_{2m},
\quad
P_mB_{2m},
\quad
Q_mA_{2m},
\quad
Q_mB_{2m}
\]

belong to the rank-four tensor product of the two second-order recurrence modules.

Therefore

\[
D_m=P_mA_{2m}-2B_{2m}Q_m
\]

satisfies an explicit fourth-order recurrence.

A fully algebraic proof would:

1. derive the second-order recurrence for the even subsequences
   \[
   A_{2m},\qquad B_{2m};
   \]

2. form the \(4\times4\) tensor transfer matrix;

3. define
   \[
   E_m=2^{1-4m}D_m;
   \]

4. find a stable integral \(\mathbf Z_2\)-lattice for the normalized transfer action;

5. prove
   \[
   E_m\in\mathbf Z_2^\times
   \]
   for every \(m\).

This would prove the Gap Lemma directly.

### Route B: \(2\times2\) cross-minor matrix

Rather than scalarizing to order four, define the four cross minors obtained from the two adjacent Zudilin vectors and two adjacent modular-\(E\) vectors.

The resulting \(2\times2\) minor matrix evolves by left and right multiplication by the two order-two transfer matrices.

A suitable diagonal \(2\)-adic gauge may reveal a stable matrix lattice whose distinguished entry is exactly

\[
2^{1-4m}
(P_mA_{2m}-2B_{2m}Q_m).
\]

This may produce the shortest elementary induction.

### Route C: common Frobenius extension

Prove that the two realizations define the same conductor-\(4\), weight-two extension class at \(p=2\).

Then

\[
\mathcal G_{Z,2}
=
\mathcal G_{E,2}
\]

follows conceptually.

This would be the strongest explanation from the three-layer theory, but requires more \(p\)-adic functoriality than the purely recurrence-theoretic routes.

### Route D: repair the Padé argument

Use the Rivoal-Beukers correspondence, but prove a genuinely uniform moving-point estimate at

\[
x_m=\frac12-m.
\]

The required statement must control the quotient of the Padé remainder by the moving denominator polynomial.

A fixed-\(x\) approximation theorem is insufficient.

---

# 31. Final theorem in compact form

Subject only to the Gap Lemma

\[
v_2(P_mA_{2m}-2B_{2m}Q_m)=4m-1,
\]

the two Catalan realizations at indices

\[
m=3n,
\qquad
2m=6n
\]

possess:

\[
D_{6n}^2
\]

of common LCM-square arithmetic;

an additional exterior-power divisor

\[
2^{24n};
\]

a double-congruence coefficient lattice whose covolume can be normalized to

\[
D_{6n}^2\,2^{24n+O(1)};
\]

archimedean rates

\[
(A_E,E_E)
=
(12+18\log2,\;12+12\log2),
\]

and

\[
(A_Z,E_Z)
=
(12+12\log2+15\log\phi,\;
12+12\log2-15\log\phi);
\]

and hence a two-successive-minima approximation with

\[
H
=
6+\frac{45}{2}\log\phi,
\]

\[
F
=
6-\frac{15}{2}\log\phi.
\]

Therefore

\[
\boxed{
\delta_{\mathrm{Cat}}
\ge
1-\frac FH
=
\frac{30\log\phi}
{6+\frac{45}{2}\log\phi}
=
0.85791445247361753937\ldots.
}
\]

This is the exact headline worthiness result.

It remains below the irrationality threshold \(1\), so even after the Gap Lemma is proved it does not prove the irrationality of Catalan's constant.

Its significance is that the improvement comes from a finite-place correlation between two distinct Catalan realizations, detected by an exterior-power/Plücker divisor that is invisible in the denominator arithmetic of either row separately.