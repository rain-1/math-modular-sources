# What is still needed from you

**Short answer: nothing, unless you want the prime number theorem discharged as well.**

Every statement that this note previously listed as an imported hypothesis has since been
proved inside the project:

| Formerly imported | Now proved in |
|---|---|
| Beukers' `2`-adic Padé estimate | `PadeEstimate.lean` |
| Rivoal's numerator identity (4.9) | `RivoalP.lean` |
| Integrality of the second numerator row `Y₂` | `Y2Integrality.lean` |
| `α = G_Z` (limit of the Zudilin row is Catalan's constant) | `ZudilinLimit.lean` |
| `α = G_E` (limit of the modular row is Catalan's constant) | `EAbelLimit.lean`, `CatalanIntegral.lean`, `CatalanAccel.lean` |

See `REMAINING_HYPOTHESES.md` for the full list and for the shape of the proofs.

---

## The one thing left: `rate_D`

```lean
rate_D : LogRate (fun N => ((Dlcm N : ℕ) : ℝ)) 1     -- log lcm(1,…,N) = N + o(N)
```

This is the prime number theorem, kept as a hypothesis on purpose.  Mathlib (at the version
pinned by this project) proves Chebyshev-type bounds — `θ x ≤ (log 4) x`, the corresponding
upper bound on `π` — but not the asymptotic `ψ(N) ∼ N` that `rate_D` needs, so discharging it
means formalizing a proof of the prime number theorem.  Nothing is needed from you for that; say
the word if you would like it attempted, or supply a preferred route (e.g. a Newman-style
Tauberian argument) if you have one in mind.

Everything else in the development is unconditional: `lake build` is clean, and there is no
`sorry` and no `axiom` in `RequestProject/`.
