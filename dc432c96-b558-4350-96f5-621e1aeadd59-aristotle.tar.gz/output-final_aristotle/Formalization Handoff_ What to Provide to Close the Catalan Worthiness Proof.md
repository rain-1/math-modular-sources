# Formalization Handoff: What to Provide to Close the Catalan Worthiness Proof

## Purpose

The Lean development has already formalized most of the Catalan-worthiness argument. The remaining work is concentrated in a small number of explicitly named hypotheses. The goal of this note is to specify the mathematical artifacts that should be supplied so those hypotheses can be discharged with minimal additional library development.

The governing principle is:

> Prefer finite algebraic identities, recurrences with certificates, and prime-by-prime valuation arguments over general hypergeometric, contour-integral, or modular-analytic machinery.

The existing Lean project is already well equipped for:

- three-term recurrence uniqueness;
- finite binomial and factorial sums;
- creative-telescoping certificates;
- Legendre-formula and carry-counting valuation arguments;
- \(2\)-adic valuations;
- elementary finite sums;
- LCM denominator arguments.

It is comparatively expensive to formalize:

- contour integrals;
- residue calculus;
- general hypergeometric transformation theory;
- saddle-point asymptotics;
- appeals to modular-form folklore without explicit identities.

The uploaded formalization note confirms that this is the intended division of labor.

---

# 1. Highest-priority target: a closed form for Beukers' numerator \(p_n(x)\)

This is the single highest-leverage artifact because it helps with three separate remaining hypotheses.

Beukers' Padé recurrence is

\[
(n+1)^2u_{n+1}
=
\bigl(2n(n+1)+1-x+x^2\bigr)u_n
-
n^2u_{n-1},
\]

with denominator solution

\[
q_0(x)=1,
\qquad
q_1(x)=x^2-x+1,
\]

and numerator solution

\[
p_0(x)=0,
\qquad
p_1(x)=1.
\]

The denominator already has the finite form used in the Lean project:

\[
q_n(x)
=
\sum_{k=0}^n
\binom nk\,
\frac{\beta_k(y)}{(k!)^2},
\qquad
y=x^2-x,
\]

where

\[
\beta_k(y)
=
\prod_{j=0}^{k-1}
\bigl(y-j(j+1)\bigr).
\]

What is now wanted is an equally explicit formula

\[
\boxed{
p_n(x)=\sum_{k=0}^n T_{n,k}(x)
}
\]

or

\[
\boxed{
p_n(x)=
\sum_{k=0}^n
\binom nk
\frac{\beta_k(y)}{(k!)^2}
\,H_{n,k}(x)
}
\]

with \(H_{n,k}\) an explicit rational/harmonic expression.

The ideal output should include:

1. the exact summand;
2. the summation range;
3. the values at \(n=0,1\);
4. an explicit creative-telescoping certificate proving the recurrence.

The certificate should be presented as a rational function \(F(n,k,x)\) satisfying an identity of the form

\[
L_n T_{n,k}
=
F(n,k+1,x)-F(n,k,x),
\]

where \(L_n\) is the Beukers recurrence operator in \(n\).

The derivation of the certificate is unnecessary for formalization. The certificate itself is enough.

This should be considered **Task A**.

---

# 2. Rivoal's diagonal numerator identity

The Lean target is

\[
\boxed{
P_m
=
Q_m\sigma_m
+
\frac{(-1)^m}{8}
p_m\!\left(\frac12-m\right),
}
\tag{R}
\]

where

\[
\sigma_m
=
\sum_{j=0}^{m-1}
\frac{(-1)^j}{(2j+1)^2}.
\]

In Lean terminology this is `PadeInputs.rivoal_p`.

The denominator identity

\[
q_m\!\left(\frac12-m\right)=Q_m
\]

is already formalized.

Therefore there are two particularly efficient ways to prove (R).

## Preferred route

Once Task A supplies an explicit \(p_n(x)\), define

\[
u_m
=
p_m\!\left(\frac12-m\right).
\]

Derive an explicit recurrence for \(u_m\).

Then define

\[
R_m
=
Q_m\sigma_m+\frac{(-1)^m}{8}u_m.
\]

Use

\[
\sigma_{m+1}
=
\sigma_m
+
\frac{(-1)^m}{(2m+1)^2}
\]

and the recurrences for \(Q_m,u_m\) to prove that \(R_m\) satisfies Zudilin's recurrence.

Finally check

\[
R_0=0=P_0,
\]

and

\[
R_1
=
\frac74-\frac18
=
\frac{13}{8}
=
P_1.
\]

Recurrence uniqueness then gives

\[
R_m=P_m
\]

for every \(m\).

The most useful artifact here would therefore be:

\[
\boxed{\text{an explicit recurrence in }m\text{ for }
u_m=p_m(1/2-m),}
\]

including its polynomial coefficients.

This is **Task B**.

---

# 3. Explicit Zudilin numerator \(P_m\)

There is a second route to Task B that may also be valuable for later odd-prime arithmetic.

The Zudilin denominator has the explicit terminating hypergeometric form

\[
Q_n
=
\sum_{j=0}^{n}
\binom nj
\binom{n-\frac12}{j}
\binom{n+j-\frac12}{j}.
\]

Equivalently,

\[
Q_n
=
{}_3F_2
\left(
\begin{matrix}
-n,\frac12-n,\frac12+n\\
1,1
\end{matrix}
;1
\right).
\]

A factorial-only form is

\[
Q_n
=
\sum_{j=0}^n
\frac{
n!(2n+2j)!
}{
16^j(n+j)!(2n-2j)!(j!)^3
}.
\]

For the numerator, our useful single-index harmonic formulation is obtained from Zudilin's partial fractions.

Define

\[
\mathcal W_{n,k}
=
\frac{
n!(k+\frac12)_n(n-k+\frac12)_n
}{
(k!)^3((n-k)!)^3
},
\]

or equivalently

\[
\mathcal W_{n,k}
=
\frac{
n!(2n+2k)!(4n-2k)!
}{
16^n(k!)^2((n-k)!)^2
(n+k)!(2n-k)!(2k)!(2n-2k)!
}.
\]

Let

\[
d_{n,k}=n-2k.
\]

Define

\[
H_m^{(r)}
=
\sum_{j=1}^m\frac1{j^r},
\qquad
H_0^{(r)}=0,
\]

and

\[
O_m^{(r)}
=
\sum_{j=0}^{m-1}
\frac1{(j+\frac12)^r}
=
2^rH_{2m}^{(r)}-H_m^{(r)}.
\]

Set

\[
\begin{aligned}
L_{n,k}
={}&
-\bigl(O_{n+k}^{(1)}-O_k^{(1)}\bigr)
+\bigl(O_{2n-k}^{(1)}-O_{n-k}^{(1)}\bigr)\\
&+3H_k^{(1)}-3H_{n-k}^{(1)},
\end{aligned}
\]

and

\[
\begin{aligned}
M_{n,k}
={}&
-\bigl(O_{n+k}^{(2)}-O_k^{(2)}\bigr)
-\bigl(O_{2n-k}^{(2)}-O_{n-k}^{(2)}\bigr)\\
&+3H_k^{(2)}+3H_{n-k}^{(2)}.
\end{aligned}
\]

Finally put

\[
\beta_k^{(r)}
=
\sum_{j=0}^{k-1}
\frac{(-1)^j}{(2j+1)^r}.
\]

Then

\[
Q_n
=
\frac{(-1)^n}{2}
\sum_{k=0}^n
\mathcal W_{n,k}
\left(
2+d_{n,k}L_{n,k}
\right),
\]

and

\[
\begin{aligned}
P_n
=
(-1)^n
\sum_{k=0}^n
\mathcal W_{n,k}
\Bigg[
&d_{n,k}\beta_k^{(3)}
\\
&+
\frac12
\left(2+d_{n,k}L_{n,k}\right)
\beta_k^{(2)}
\\
&+
\frac14
\left(
2L_{n,k}
+
\frac{d_{n,k}}2
(L_{n,k}^2+M_{n,k})
\right)
\beta_k^{(1)}
\Bigg].
\end{aligned}
\tag{P}
\]

This is potentially very useful to Lean because it removes the nested Padé numerator sum.

To make (P) formalization-friendly, what is still desirable is:

\[
\boxed{
\text{a telescoping certificate proving that (P) satisfies
Zudilin's recurrence.}
}
\]

That would provide an entirely independent formal proof of the numerator formula.

This is **Task C**.

---

# 4. Integrality of the Zudilin second row

The Lean theorem needs an integer sequence \(Y_2(n)\) satisfying

\[
Y_2(n)
=
2^{e_{\mathrm{Zud}}(3n)}
D_{6n}^2P_{3n}.
\]

Once Rivoal's identity is available,

\[
P_m
=
Q_m\sigma_m
+
\frac{(-1)^m}{8}p_m(x_m),
\qquad
x_m=\frac12-m,
\]

most of this is already controlled:

- sufficient integrality of \(2^eQ_m\) is proved;
- \(D_{2m-1}^2\sigma_m\in\mathbf Z\) is elementary.

The remaining denominator problem reduces to the diagonal Padé numerator.

A sufficient statement is

\[
\boxed{
2^{4m+3}
D_{2m-1}^2\,
p_m\!\left(\frac12-m\right)
\in\mathbf Z.
}
\tag{I}
\]

A somewhat stronger or differently normalized factor is fine provided that at \(m=3n\) it divides the already available normalization

\[
2^{e_{\mathrm{Zud}}(3n)}D_{6n}^2.
\]

The best proof format is prime-by-prime.

For each term \(T_{m,k}\) of a closed form for \(p_m(x_m)\), prove an explicit inequality

\[
v_p(T_{m,k})
+
v_p\!\left(
2^{4m+3}D_{2m-1}^2
\right)
\ge0
\]

for every prime \(p\).

For odd \(p\), this should ideally be written using

\[
v_p(r!)
=
\sum_{\ell\ge1}
\left\lfloor\frac r{p^\ell}\right\rfloor
\]

and simple floor inequalities.

For \(p=2\), a carry-counting or binary-digit formulation is preferable.

This is **Task D**.

---

# 5. The Beukers \(2\)-adic Padé estimate

The formal target is approximately

\[
\left\|
p_n(a/2)
-
\Xi(a/2)q_n(a/2)
\right\|_2
\le
4n^2\,2^{-4n},
\]

for odd \(a\) and \(n\ge1\).

The note correctly identifies the cheapest proof as a Casoratian-tail argument.

Let

\[
W_n(x)
=
p_{n+1}(x)q_n(x)
-
p_n(x)q_{n+1}(x).
\]

Because both sequences satisfy the same second-order recurrence, \(W_n\) satisfies a first-order recurrence.

For

\[
(n+1)^2u_{n+1}
=
A_n(x)u_n-n^2u_{n-1},
\]

with

\[
A_n(x)
=
2n(n+1)+1-x+x^2,
\]

we have

\[
W_n
=
\frac{n^2}{(n+1)^2}
W_{n-1}.
\]

Since

\[
W_0=p_1q_0-p_0q_1=1,
\]

it follows immediately that

\[
\boxed{
W_n(x)=\frac1{(n+1)^2}.
}
\tag{W}
\]

This is independent of \(x\).

Hence

\[
\frac{p_{n+1}}{q_{n+1}}
-
\frac{p_n}{q_n}
=
\frac{1}{(n+1)^2q_nq_{n+1}}.
\]

If the Padé ratio converges \(2\)-adically to \(\Xi(x)\), then telescoping gives

\[
\boxed{
\Xi(x)-\frac{p_n(x)}{q_n(x)}
=
\sum_{j=n}^{\infty}
\frac{1}
{(j+1)^2q_j(x)q_{j+1}(x)}.
}
\tag{T}
\]

Equivalently,

\[
\boxed{
p_n(x)-\Xi(x)q_n(x)
=
-q_n(x)
\sum_{j=n}^{\infty}
\frac1{(j+1)^2q_j(x)q_{j+1}(x)}.
}
\tag{T'}
\]

This is exactly the kind of remainder formula the formalization note requests.

Therefore what is needed for the Lean estimate is reduced to:

1. prove the convergence of the right-hand side for \(x=a/2\), \(a\) odd;
2. supply an explicit lower bound for
   \[
   v_2(q_j(a/2));
   \]
3. show that the first tail term has valuation at least
   \[
   4n-O(\log n);
   \]
4. translate that into any explicit estimate
   \[
   Cn^A2^{-4n}.
   \]

The downstream argument does not require the exact constant \(4n^2\); any fixed \(C,A\) with exponential factor \(2^{-4n}\) suffices.

This is **Task E**.

---

# 6. Equality of the real limits

The worthiness theorem itself no longer requires prior identification with the classical Catalan constant.

It needs only

\[
\boxed{
G_E^{\mathbf R}
=
G_Z^{\mathbf R}.
}
\tag{L}
\]

Here

\[
G_E^{\mathbf R}
=
\lim_{n\to\infty}\frac{2B_n}{A_n},
\]

and

\[
G_Z^{\mathbf R}
=
\lim_{m\to\infty}\frac{P_m}{Q_m}.
\]

The Lean assembly theorem already accepts this one equality as the analytic bridge.

There are several ways to discharge it.

## Route 1: identify both with Catalan's constant

For the \(E\)-family, use an explicit remainder formula for

\[
\frac G2A_n-B_n.
\]

The recurrence has Wronskian

\[
A_nB_{n-1}-A_{n-1}B_n
=
-\frac{32^{n-1}}{n^2}.
\]

Therefore

\[
\frac{B_n}{A_n}
-
\frac{B_{n-1}}{A_{n-1}}
=
\frac{32^{n-1}}
{n^2A_nA_{n-1}}.
\]

Since \(B_0/A_0=0\),

\[
\boxed{
\frac{B_n}{A_n}
=
\sum_{r=1}^{n}
\frac{32^{r-1}}
{r^2A_rA_{r-1}}.
}
\]

Hence

\[
\boxed{
\frac{G}{2}
-
\frac{B_n}{A_n}
=
\sum_{r=n+1}^{\infty}
\frac{32^{r-1}}
{r^2A_rA_{r-1}},
}
\tag{E-rem}
\]

provided one establishes the identity

\[
\boxed{
\frac G2
=
\sum_{r=1}^{\infty}
\frac{32^{r-1}}
{r^2A_rA_{r-1}}.
}
\tag{E-G}
\]

For formalization, (E-G) is much easier if supplied as an elementary series identity than via modular Eichler integrals.

For the Zudilin side, Rivoal's identity gives

\[
\frac{P_m}{Q_m}
=
\sigma_m
+
\frac{(-1)^m}{8}
\frac{p_m(x_m)}{q_m(x_m)}.
\]

Since

\[
\sigma_m\to G,
\]

it is enough to show

\[
\frac{p_m(x_m)}{q_m(x_m)}\to0
\qquad\text{over }\mathbf R.
\]

Any explicit elementary upper bound of the form

\[
\left|
\frac{p_m(x_m)}{q_m(x_m)}
\right|
\le Cr^m,
\qquad0<r<1,
\]

or even \(o(1)\), is sufficient.

This may be easier than importing the whole Padé approximation theory.

This is **Task F**.

---

# 7. Closed forms for the modular \(E\)-family

These are already particularly friendly for formalization.

The homogeneous sequence is

\[
\boxed{
A_n
=
\sum_{k=\lceil n/2\rceil}^{n}
(-4)^{n-k}
\binom{k}{n-k}
\binom{2k}{k}^2.
}
\tag{A}
\]

For the companion, define

\[
C_k
=
\frac14
\sum_{j=0}^{k-1}
\frac{4^j}
{\binom{2j}{j}(2j+1)^2}.
\]

Then

\[
\boxed{
B_n
=
\sum_{k=\lceil n/2\rceil}^{n}
(-4)^{n-k}
\binom{k}{n-k}
\binom{2k}{k}^2C_k.
}
\tag{B}
\]

Equivalently,

\[
\boxed{
B_n=
\frac14
\sum_{k=\lceil n/2\rceil}^{n}
(-4)^{n-k}
\binom{k}{n-k}
\binom{2k}{k}^2
\sum_{j=0}^{k-1}
\frac{4^j}
{\binom{2j}{j}(2j+1)^2}.
}
\]

The uploaded project notes record the \(E\)-family recurrence, its modular source, the initial values, the Wronskian, and its Catalan interpretation.

If these formulas are not already formalized completely, useful certificates would be:

- one Zeilberger certificate for (A);
- one certificate or direct inhomogeneous-recurrence verification for (B).

These are not the highest-priority missing items, because much of the \(E\)-family is already in Lean.

---

# 8. The exact cross-\(2\)-adic theorem

The mathematical theorem eventually wanted is

\[
\boxed{
v_2
\left(
P_mA_{2m}
-
2B_{2m}Q_m
\right)
=
4m-1.
}
\tag{CROSS}
\]

The existing mathematics reduces this to equality of two \(2\)-adic limits together with exact tail valuations.

However, from the perspective of formalization, there are two strategies.

## Strategy 1: period comparison

Formalize:

\[
G_{Z,2}=G_{E,2}.
\]

Then combine the already elementary recurrence/Wronskian valuation formulas.

This is conceptually satisfying but requires more \(2\)-adic analytic infrastructure.

## Strategy 2: direct finite-sum proof

Use the explicit forms for

\[
A_{2m},B_{2m},Q_m,P_m
\]

and prove CROSS directly.

This route is particularly attractive now that both pairs have explicit finite sums.

It may also generalize to odd primes.

For a formal proof, an inequality is insufficient because the worthiness construction uses a large guaranteed modulus. Fortunately, for that application the exact equality can be weakened to

\[
\boxed{
v_2
\left(
P_mA_{2m}
-
2B_{2m}Q_m
\right)
\ge4m-1.
}
\tag{CROSS-LOWER}
\]

The equality is aesthetically stronger, but the lower bound is what creates the divisor.

Thus, if direct exact equality becomes cumbersome, formalize CROSS-LOWER first.

---

# 9. Odd-prime extension: the next research target

Once the finite-sum formulas are formalized, the natural next object is

\[
\Delta_n
=
P_nA_{2n}-2B_{2n}Q_n.
\]

For each odd prime \(p\), study

\[
v_p(\Delta_n).
\]

The desired phenomenon is not necessarily a valuation linear in \(n\) at every fixed \(p\). The more promising possibility is a collection of prime windows

\[
\alpha_i n<p\le\beta_i n
\]

on which

\[
v_p(\Delta_n)\ge1
\]

or higher.

If \(\mathcal P_n\) is such a systematic collection, define

\[
T_n^{\mathrm{odd}}
=
\prod_{p\in\mathcal P_n}p^{v_p(\Delta_n)}.
\]

Then

\[
\frac1n\log T_n^{\mathrm{odd}}
=
\frac1n
\sum_{p\in\mathcal P_n}
v_p(\Delta_n)\log p.
\]

Any positive limiting mass here adds directly to the finite-place modulus in the double-congruence lattice.

Thus even a modest odd-prime mass can improve

\[
0.8579144524\ldots.
\]

The factorial kernel in the closed form

\[
\mathcal W_{n,k}
\]

is ideal for Legendre/Kummer analysis, while the harmonic factors naturally invite:

- Wolstenholme-type congruences;
- reflection \(k\leftrightarrow n-k\);
- finite-field hypergeometric identities;
- character-sum cancellation.

This is the main research direction after the formalization bottlenecks are removed.

---

# 10. Recommended order of attack

For maximum leverage, proceed in the following order.

### Priority 1 — Beukers numerator

Produce

\[
p_n(x)=\text{explicit finite sum}
\]

plus a telescoping certificate.

This helps Tasks A, B, D, and E simultaneously.

### Priority 2 — diagonal recurrence

Produce a recurrence for

\[
u_m=p_m(1/2-m).
\]

Then Rivoal's numerator identity becomes almost automatic.

### Priority 3 — diagonal denominator theorem

Prove

\[
2^{4m+3}D_{2m-1}^2u_m\in\mathbf Z.
\]

This discharges the missing integer second row.

### Priority 4 — real limit equality

Give elementary remainder formulas showing

\[
G_E^{\mathbf R}=G_Z^{\mathbf R}=G.
\]

For the formal worthiness theorem itself, only

\[
G_E^{\mathbf R}=G_Z^{\mathbf R}
\]

is needed.

### Priority 5 — Padé \(2\)-adic remainder

Use the Casoratian

\[
W_n=\frac1{(n+1)^2}
\]

and tail formula (T') to prove the \(2^{-4n}\) estimate.

### Priority 6 — odd-prime cross arithmetic

With all four sequences explicit, search and prove prime-window divisibility of

\[
\Delta_n=P_nA_{2n}-2B_{2n}Q_n.
\]

This is the part most likely to improve the worthiness beyond

\[
0.8579144524\ldots.
\]

---

# 11. Minimal package to send back to the formalizer

If only a compact package is desired, send the following six items.

1. **Closed form for \(p_n(x)\).**

2. **Telescoping certificate for that closed form.**

3. **Moving-point recurrence for**
   \[
   p_m(1/2-m).
   \]

4. **Prime-by-prime denominator lemma**
   \[
   2^{4m+3}D_{2m-1}^2p_m(1/2-m)\in\mathbf Z.
   \]

5. **Casoratian and Padé tail**
   \[
   W_n=\frac1{(n+1)^2},
   \]
   \[
   p_n-\Xi q_n
   =
   -q_n
   \sum_{j=n}^\infty
   \frac1{(j+1)^2q_jq_{j+1}},
   \]
   together with a valuation bound giving exponential rate \(2^{-4n}\).

6. **One elementary identity proving**
   \[
   G_E^{\mathbf R}=G_Z^{\mathbf R}.
   \]

With those six artifacts, the uploaded formalization note indicates that the remaining Catalan worthiness assembly becomes routine relative to infrastructure already present in the project.

---

# 12. Headline theorem once these inputs are discharged

The resulting formal theorem is the existence of an admissible rational approximation sequence to the common Catalan limit with worthiness at least

\[
\boxed{
\delta
\ge
\frac{30\log\phi}
{6+\frac{45}{2}\log\phi}
=
0.8579144524736\ldots,
}
\]

where

\[
\phi=\frac{1+\sqrt5}{2}.
\]

To identify the common limit with the classical Catalan constant

\[
G
=
\sum_{k=0}^{\infty}
\frac{(-1)^k}{(2k+1)^2},
\]

one additionally proves either

\[
G_E^{\mathbf R}=G
\]

or

\[
G_Z^{\mathbf R}=G.
\]

The formal worthiness inequality itself needs only equality of the two real limits.

---

## Short version

The highest-leverage mathematical contribution to provide next is:

\[
\boxed{
\text{an explicit finite formula for Beukers' }p_n(x)
\text{ with a telescoping certificate.}
}
\]

After that, the diagonal identity, the missing integrality theorem, and the \(2\)-adic Padé estimate all become much more elementary.

The next research-level payoff is to use the explicit formulas for all four sequences

\[
A_n,\ B_n,\ Q_n,\ P_n
\]

to analyze

\[
P_nA_{2n}-2B_{2n}Q_n
\]

at odd primes and look for additional positive-density prime mass beyond the already proved \(2\)-adic contribution.