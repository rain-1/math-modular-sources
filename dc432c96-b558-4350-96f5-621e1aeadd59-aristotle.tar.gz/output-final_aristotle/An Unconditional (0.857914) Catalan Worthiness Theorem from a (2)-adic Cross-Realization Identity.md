# An Unconditional \(0.857914\) Catalan Worthiness Theorem from a \(2\)-adic Cross-Realization Identity

## Closing the Padé gap, proving the exact Plücker valuation, and repairing the balanced-minima argument

### Abstract

Let
\[
G=\beta(2)=\sum_{k=0}^{\infty}\frac{(-1)^k}{(2k+1)^2}
\]
be Catalan's constant. The preceding note constructed two rational Catalan rows: a Zudilin hypergeometric row \(P_m/Q_m\) and a modular \(E\)-family row \(2B_n/A_n\). It proved the archimedean estimates, denominator estimates, Wronskians, exact \(2\)-adic tail valuations, coefficient-lattice argument, and two-row geometry-of-numbers step, but left one arithmetic identification as a hypothesis:
\[
\mathcal G_{Z,2}=\mathcal G_{E,2}.
\]
The exact tails proved there reduce the former Gap Lemma to this single equality.

This note proves that identity. The proof repairs the moving-point Padé argument suggested in the earlier note. The key point is that Beukers's \(p\)-adic Padé remainder estimate is uniform in the numerator of \(x=a/F\). At
\[
x_m=\frac12-m=\frac{1-2m}{2}
\]
it therefore remains exponentially strong even though the point moves with the Padé degree. Rivoal's exact hypergeometric identification then shows that the Zudilin \(2\)-adic limit is a fixed Padé value \(\xi/8\).

A second identity shows that the modular \(E\)-family is the quadratic pullback
\[
t=16z(1-4z),\qquad y\longmapsto(1-8z)y
\]
of Beukers's fixed-\(x=\tfrac12\) differential equation. The same Padé value \(\xi/8\) is therefore the \(2\)-adic limit of \(2B_n/A_n\).

Consequently
\[
\boxed{\mathcal G_{Z,2}=\mathcal G_{E,2}},
\]
and hence, for every \(m\ge1\),
\[
\boxed{
v_2\!\left(P_mA_{2m}-2B_{2m}Q_m\right)=4m-1.
}
\]
The formerly conditional Plücker divisor \(2^{24n}\) is unconditional, and the construction gives
\[
\boxed{
\delta_{\rm Cat}\ge
\frac{30\log\phi}{6+\frac{45}{2}\log\phi}
=
0.8579144524736175393706930538\ldots
}
\]
with
\[
\phi=\frac{1+\sqrt5}{2}.
\]

The final section also corrects a proof-hygiene issue in the earlier two-successive-minima theorem: the natural conclusion is a bound on the ratio of the linear-form exponent to the height exponent, rather than a separate uniform upper bound for the linear form in one exceptional case.

---

## 1. What is inherited from the base note

We retain the notation and proved results of the preceding note.

The Zudilin row satisfies
\[
\frac{P_m}{Q_m}\longrightarrow G
\]
in the real topology, and
\[
\boxed{v_2(Q_m)=-4m+2s_2(m)}
\tag{1.1}
\]
and
\[
\boxed{v_2(P_m)=-4m+2s_2(m)-1}.
\tag{1.2}
\]

Its rational approximants converge in \(\mathbf Q_2\) to a limit \(\mathcal G_{Z,2}\), with exact tail
\[
\boxed{
v_2\!\left(
\mathcal G_{Z,2}-\frac{P_m}{Q_m}
\right)
=
8m-1-4s_2(m).
}
\tag{1.3}
\]

The modular \(E\)-row is defined by
\[
(n+1)^2u_{n+1}
=
(12n(n+1)+4)u_n
-
32n^2u_{n-1},
\tag{1.4}
\]
with
\[
(A_0,A_1)=(1,4),
\qquad
(B_0,B_1)=(0,1).
\tag{1.5}
\]
The base note proves
\[
\boxed{v_2(A_n)=2s_2(n)}
\tag{1.6}
\]
and
\[
\boxed{v_2(B_n)=2s_2(n)-2\qquad(n\ge1)}.
\tag{1.7}
\]
Moreover
\[
R_n^E=\frac{2B_n}{A_n}
\]
converges in \(\mathbf Q_2\) to a limit \(\mathcal G_{E,2}\), with
\[
\boxed{
v_2\!\left(
\mathcal G_{E,2}-\frac{2B_n}{A_n}
\right)
=
5n-1-4s_2(n).
}
\tag{1.8}
\]
In particular,
\[
\boxed{
v_2\!\left(
\mathcal G_{E,2}-\frac{2B_{2m}}{A_{2m}}
\right)
=
10m-1-4s_2(m).
}
\tag{1.9}
\]


Everything below is devoted to proving that the two limits in (1.3) and (1.8) are the same.

---

## 2. A sign-safe Padé normalization

Use Beukers's bracket
\[
\left[\frac{k}{x}\right]
=
\frac{k!}{x(x+1)\cdots(x+k)}.
\tag{2.1}
\]

The arXiv version of Beukers's paper contains a sign mismatch between the displayed series representation and a subsequent displayed functional equation. Proposition 4.1 displays
\[
\Theta(x)
=
-\sum_{k\ge0}
\left[\frac{k}{x}\right]
\left[\frac{k}{1-x}\right],
\]
while the Padé normalization in Section 6 is consistent with that negative-series convention. To eliminate any ambiguity, define directly
\[
\boxed{
\Xi(x)
=
-\sum_{k=0}^{\infty}
\left[\frac{k}{x}\right]
\left[\frac{k}{1-x}\right].
}
\tag{2.2}
\]
For \(x=a/F\) with \(2\mid F\) and \(a\) odd, this series has its corresponding \(2\)-adic value.

The telescoping calculation in Beukers's proof shows that the *unnegated* sum satisfies the relation with right side \(-2/x^2\). Therefore the normalization (2.2) satisfies

### Lemma 2.1
\[
\boxed{
\Xi(x+1)+\Xi(x)=\frac{2}{x^2}.
}
\tag{2.3}
\]

Set
\[
\boxed{\xi=\Xi(1/2)\in\mathbf Q_2.}
\tag{2.4}
\]

---

## 3. Beukers's Padé pair and the uniform moving-point estimate

Let \(p_n(x),q_n(x)\) be the two solutions of
\[
(n+1)^2u_{n+1}
=
\bigl(2n(n+1)+1-x+x^2\bigr)u_n
-
n^2u_{n-1},
\tag{3.1}
\]
with
\[
q_0=1,\qquad q_1=x^2-x+1,
\tag{3.2}
\]
and
\[
p_0=0,\qquad p_1=1.
\tag{3.3}
\]
Beukers derives this recurrence and the associated differential equation in Section 6.

The point that repairs the earlier gap is the following direct specialization of Proposition 7.1.

### Lemma 3.1 — uniform \(2\)-adic Padé estimate

For every odd integer \(a\) and every \(n\ge1\),
\[
\boxed{
\left|
p_n(a/2)-\Xi(a/2)q_n(a/2)
\right|_2
\le
4n^2\,2^{-4n}.
}
\tag{3.4}
\]
Equivalently,
\[
\boxed{
v_2\!\left(
p_n(a/2)-\Xi(a/2)q_n(a/2)
\right)
\ge
4n-O(\log n),
}
\tag{3.5}
\]
where the implicit constant is independent of \(a\).

### Proof

Beukers's Proposition 7.1(4) states that if \(x=a/F\), \(p^r\Vert F\), and \(p\nmid a\), then
\[
|p_n(a/F)-\Xi_p(a/F)q_n(a/F)|_p
\le
p^2n^2p^{-2n(r+1/(p-1))}.
\]


Take
\[
p=2,\qquad F=2,\qquad r=1.
\]
Then
\[
2n\left(r+\frac1{p-1}\right)=4n,
\]
which gives (3.4).

The decisive feature is that the right side contains no dependence on the odd numerator \(a\). \(\square\)

Thus the estimate applies uniformly to the moving sequence
\[
\boxed{x_m=\frac12-m=\frac{1-2m}{2}.}
\tag{3.6}
\]

This is precisely the condition that the earlier warning identified as missing.

---

## 4. Exact Rivoal–Beukers identification

Write Rivoal's Padé polynomials as
\[
\mathscr P_{2n}(z),\qquad \mathscr Q_{2n}(z)
\]
to distinguish them from the Zudilin sequences \(P_n,Q_n\).

Comparison of Rivoal's explicit Padé formulas with Beukers's formulas gives
\[
\boxed{
q_n(x)=\mathscr P_{2n}(1-2x)
}
\tag{4.1}
\]
and
\[
\boxed{
p_n(x)=\frac{4}{1-2x}\,
\mathscr Q_{2n}(1-2x).
}
\tag{4.2}
\]
Beukers explicitly notes that the \(x=-n+\tfrac12\) specialization is the one occurring in Rivoal's Catalan construction.

Rivoal's hypergeometric Catalan sequences \(a_n,b_n\) satisfy exactly the recurrence used for the Zudilin row, with
\[
a_0=4,\qquad a_1=7,
\qquad
b_0=0,\qquad b_1=\frac{13}{2}.
\]


Since the base-note normalization is
\[
Q_0=1,\qquad Q_1=\frac74,
\qquad
P_0=0,\qquad P_1=\frac{13}{8},
\]
uniqueness gives
\[
\boxed{
a_n=4Q_n,\qquad b_n=4P_n.
}
\tag{4.3}
\]

Rivoal's Theorem 2 proves
\[
a_n=4\mathscr P_{2n}(2n)
\tag{4.4}
\]
and, with
\[
\sigma_n
=
\sum_{k=0}^{n-1}\frac{(-1)^k}{(2k+1)^2},
\tag{4.5}
\]
his preceding formula gives
\[
b_n
=
4\mathscr P_{2n}(2n)\sigma_n
+
(-1)^n\frac1n\mathscr Q_{2n}(2n).
\tag{4.6}
\]


At
\[
x_m=\frac12-m,
\]
we have
\[
1-2x_m=2m.
\]
Equations (4.1), (4.3), and (4.4) give
\[
\boxed{
q_m(x_m)=Q_m.
}
\tag{4.7}
\]
Equation (4.2) gives
\[
\mathscr Q_{2m}(2m)=\frac m2\,p_m(x_m),
\tag{4.8}
\]
and (4.6), divided by \(4\), therefore becomes:

### Lemma 4.1 — exact moving-point identity
\[
\boxed{
P_m
=
Q_m\sigma_m
+
\frac{(-1)^m}{8}\,p_m(x_m).
}
\tag{4.9}
\]

This is an exact rational identity, not an asymptotic statement.

---

## 5. Identification of the Zudilin \(2\)-adic limit

The functional equation (2.3) can be iterated along the half-integer orbit.

### Lemma 5.1
For every \(m\ge0\),
\[
\boxed{
\Xi(x_m)=(-1)^m\bigl(\xi-8\sigma_m\bigr).
}
\tag{5.1}
\]

### Proof

The case \(m=0\) is the definition of \(\xi\).

Since
\[
x_m+1=x_{m-1},
\]
the functional equation gives
\[
\Xi(x_m)
=
\frac{2}{x_m^2}-\Xi(x_{m-1})
=
\frac{8}{(2m-1)^2}-\Xi(x_{m-1}).
\]
This is exactly the recurrence obtained from
\[
\sigma_m
=
\sigma_{m-1}
+
\frac{(-1)^{m-1}}{(2m-1)^2}.
\]
\(\square\)

Divide (4.9) by \(Q_m=q_m(x_m)\). Using (5.1),
\[
\begin{aligned}
\frac{P_m}{Q_m}-\frac{\xi}{8}
&=
\sigma_m
+
\frac{(-1)^m}{8}\frac{p_m(x_m)}{q_m(x_m)}
-\frac{\xi}{8}\\
&=
\boxed{
\frac{(-1)^m}{8}
\left(
\frac{p_m(x_m)}{q_m(x_m)}
-
\Xi(x_m)
\right).
}
\end{aligned}
\tag{5.2}
\]

The uniform estimate gives
\[
v_2\!\left(
p_m(x_m)-\Xi(x_m)q_m(x_m)
\right)
\ge
4m-O(\log m).
\tag{5.3}
\]
But
\[
q_m(x_m)=Q_m
\]
and the base note proves
\[
v_2(Q_m)=-4m+2s_2(m).
\tag{5.4}
\]
Hence
\[
\begin{aligned}
v_2\!\left(
\frac{p_m(x_m)}{q_m(x_m)}-\Xi(x_m)
\right)
&\ge
4m-O(\log m)-v_2(Q_m)\\
&=
8m-2s_2(m)-O(\log m)\\
&\longrightarrow+\infty.
\end{aligned}
\tag{5.5}
\]

Therefore:

### Theorem 5.2
\[
\boxed{
\mathcal G_{Z,2}=\frac{\xi}{8}.
}
\tag{5.6}
\]

This calculation also explains why the moving denominator is not an obstacle. Its valuation contributes approximately \(-4m\), so division by it increases the valuation of the normalized Padé error by approximately another \(4m\).

---

## 6. Quadratic pullback to the modular \(E\)-family

Now specialize Beukers's Padé system at the fixed point
\[
x=\frac12.
\]
Write
\[
q_k=q_k(1/2),\qquad p_k=p_k(1/2)
\tag{6.1}
\]
and
\[
Y_0(t)=\sum_{k=0}^{\infty}q_kt^k,
\qquad
Y_1(t)=\sum_{k=0}^{\infty}p_kt^k.
\tag{6.2}
\]

At \(x=\tfrac12\), Beukers's operator is
\[
\boxed{
L_B
=
t(t-1)^2\frac{d^2}{dt^2}
+
(3t-1)(t-1)\frac d{dt}
+
\left(t-\frac34\right).
}
\tag{6.3}
\]
Its two generating functions satisfy
\[
\boxed{
L_BY_0=0,\qquad L_BY_1=1.
}
\tag{6.4}
\]


For the modular recurrence define
\[
\theta=z\frac d{dz}
\]
and
\[
\boxed{
\mathscr L_E
=
\theta^2
-z(12\theta^2+12\theta+4)
+32z^2(\theta+1)^2.
}
\tag{6.5}
\]

With
\[
A(z)=\sum_{n\ge0}A_nz^n,
\qquad
B(z)=\sum_{n\ge0}B_nz^n,
\tag{6.6}
\]
the recurrence gives
\[
\boxed{
\mathscr L_EA=0,\qquad
\mathscr L_EB=z.
}
\tag{6.7}
\]

Now put
\[
\boxed{
t=16z(1-4z),
\qquad
g=1-8z.
}
\tag{6.8}
\]
The elementary identities
\[
t'=16g,\qquad t''=-128,\qquad 1-t=g^2
\tag{6.9}
\]
make the pullback transparent.

### Lemma 6.1 — exact quadratic pullback
For every twice differentiable function \(y(t)\),
\[
\boxed{
\mathscr L_E\!\left[g(z)y(t(z))\right]
=
16z\,(L_By)(t(z)).
}
\tag{6.10}
\]

### Proof

Write
\[
f(z)=g(z)y(t(z)).
\]
Using
\[
g'=-8,\qquad g''=0,
\qquad
t'=16g,\qquad t''=-128,
\]
differentiate twice and substitute in (6.5).

After grouping the coefficients of \(y,y',y''\), the relations
\[
1-t=g^2,\qquad t=16z(1-4z)
\]
reduce the three coefficients respectively to
\[
16z\left(t-\frac34\right),
\]
\[
16z(3t-1)(t-1),
\]
and
\[
16zt(t-1)^2.
\]
This is precisely \(16zL_By\). \(\square\)

Apply the identity to \(Y_0\). The resulting series has constant term \(1\) and satisfies the same homogeneous equation as \(A(z)\). Thus uniqueness gives
\[
\boxed{
A(z)
=
(1-8z)
Y_0\!\left(16z(1-4z)\right).
}
\tag{6.11}
\]

Similarly, because \(L_BY_1=1\),
\[
\mathscr L_E\!\left[
(1-8z)Y_1(16z(1-4z))
\right]
=
16z.
\]
Its first term is \(16z\), so comparison with \(\mathscr L_EB=z\) yields
\[
\boxed{
16B(z)
=
(1-8z)
Y_1\!\left(16z(1-4z)\right).
}
\tag{6.12}
\]

These are exact formal-power-series identities.

---

## 7. Identification of the modular \(E\)-limit

Define
\[
\varepsilon_k=p_k-\xi q_k.
\tag{7.1}
\]
The fixed-\(x=\tfrac12\) instance of Lemma 3.1 gives
\[
\boxed{
v_2(\varepsilon_k)\ge4k-O(\log k).
}
\tag{7.2}
\]

Subtract \(\xi\) times (6.11) from (6.12):
\[
\boxed{
16B(z)-\xi A(z)
=
(1-8z)
\sum_{k=0}^{\infty}
\varepsilon_k
\bigl(16z(1-4z)\bigr)^k.
}
\tag{7.3}
\]

Set
\[
D(z)
=
\sum_{k=0}^{\infty}
\varepsilon_k
\bigl(16z(1-4z)\bigr)^k.
\tag{7.4}
\]
For \(n\ge1\), a contribution to \([z^n]D(z)\) occurs only for
\[
\left\lceil\frac n2\right\rceil\le k\le n
\]
and has the form
\[
\varepsilon_k\,16^k(-4)^{n-k}
\binom{k}{n-k}.
\tag{7.5}
\]

Its valuation is at least
\[
\begin{aligned}
v_2(\varepsilon_k)
+4k+2(n-k)
&\ge
4k+4k+2(n-k)-O(\log n)\\
&=
2n+6k-O(\log n)\\
&\ge
5n-O(\log n).
\end{aligned}
\tag{7.6}
\]
Thus
\[
v_2([z^n]D(z))
\ge
5n-O(\log n).
\tag{7.7}
\]

For \(n\ge2\), multiplication by \(1-8z\) replaces this coefficient by
\[
[z^n]D(z)-8[z^{n-1}]D(z),
\]
and the shifted term also has valuation \(5n-O(\log n)\). Hence:

### Lemma 7.1
\[
\boxed{
v_2(16B_n-\xi A_n)
\ge
5n-O(\log n).
}
\tag{7.8}
\]

Since
\[
v_2(A_n)=2s_2(n)=O(\log n),
\]
we get
\[
\begin{aligned}
v_2\!\left(
\frac{2B_n}{A_n}-\frac{\xi}{8}
\right)
&=
v_2(16B_n-\xi A_n)-3-v_2(A_n)\\
&\ge
5n-O(\log n)-2s_2(n)\\
&\longrightarrow+\infty.
\end{aligned}
\tag{7.9}
\]

Therefore:

### Theorem 7.2
\[
\boxed{
\mathcal G_{E,2}=\frac{\xi}{8}.
}
\tag{7.10}
\]

Combining Theorems 5.2 and 7.2:

### Theorem 7.3 — the cross-realization identity
\[
\boxed{
\mathcal G_{Z,2}
=
\mathcal G_{E,2}
=
\frac{\xi}{8}.
}
\tag{7.11}
\]

There is no remaining Gap Hypothesis.

---

## 8. Exact cross-determinant valuation

The exact tails proved in the base note now give, for every \(m\ge1\),
\[
v_2\!\left(
\mathcal G_{Z,2}-\frac{P_m}{Q_m}
\right)
=
8m-1-4s_2(m),
\tag{8.1}
\]
and
\[
v_2\!\left(
\mathcal G_{E,2}-\frac{2B_{2m}}{A_{2m}}
\right)
=
10m-1-4s_2(m).
\tag{8.2}
\]
The second valuation is strictly larger.

Because the limiting constants are equal, the nonarchimedean equality rule for summands of unequal valuations gives
\[
\boxed{
v_2\!\left(
\frac{P_m}{Q_m}
-
\frac{2B_{2m}}{A_{2m}}
\right)
=
8m-1-4s_2(m).
}
\tag{8.3}
\]

Now
\[
P_mA_{2m}-2B_{2m}Q_m
=
Q_mA_{2m}
\left(
\frac{P_m}{Q_m}
-
\frac{2B_{2m}}{A_{2m}}
\right).
\tag{8.4}
\]
Using
\[
v_2(Q_m)=-4m+2s_2(m)
\tag{8.5}
\]
and
\[
v_2(A_{2m})
=
2s_2(2m)
=
2s_2(m),
\tag{8.6}
\]
one obtains
\[
\begin{aligned}
v_2(P_mA_{2m}-2B_{2m}Q_m)
&=
-4m+4s_2(m)
+
8m-1-4s_2(m)\\
&=
4m-1.
\end{aligned}
\]

### Theorem 8.1 — exact Plücker valuation
For every \(m\ge1\),
\[
\boxed{
v_2\!\left(
P_mA_{2m}-2B_{2m}Q_m
\right)
=
4m-1.
}
\tag{8.7}
\]

This is the former Gap Lemma, now proved.

---

## 9. The \(2^{24n}\) Plücker divisor is unconditional

At the matched indices \(m=3n\), \(2m=6n\), the base note has
\[
h_n
=
2^{e_{3n}}S_n
\left(
P_{3n}A_{6n}
-
2B_{6n}Q_{3n}
\right)
\tag{9.1}
\]
and
\[
e_{3n}\ge12n+1.
\tag{9.2}
\]

Theorem 8.1 gives
\[
v_2(P_{3n}A_{6n}-2B_{6n}Q_{3n})
=
12n-1.
\tag{9.3}
\]
Thus
\[
v_2(h_n)
\ge
(12n+1)+(12n-1)
=
24n
\]
and therefore
\[
\boxed{
2^{24n}\mid h_n.
}
\tag{9.4}
\]

The double-congruence lattice and total division modulus
\[
M_n=D_{6n}^2\,2^{24n}
\tag{9.5}
\]
from the base note are consequently available unconditionally.

---

## 10. The \(0.857914\) theorem

The archimedean rates proved in the base note are
\[
A_E=12+18\log2,
\qquad
E_E=12+12\log2,
\tag{10.1}
\]
and
\[
A_Z=12+12\log2+15\log\phi,
\qquad
E_Z=12+12\log2-15\log\phi.
\tag{10.2}
\]

The division modulus has rate
\[
\sigma=12+24\log2.
\tag{10.3}
\]

The balanced two-row calculation gives
\[
x
=
\frac{\sigma+E_Z-E_E}{2}
=
6+12\log2-\frac{15}{2}\log\phi,
\tag{10.4}
\]
hence
\[
\boxed{
H
=
6+\frac{45}{2}\log\phi
}
\tag{10.5}
\]
and
\[
\boxed{
F
=
6-\frac{15}{2}\log\phi.
}
\tag{10.6}
\]

Therefore
\[
\begin{aligned}
\delta(q,p)
&\ge
1-\frac FH\\
&=
\frac{H-F}{H}\\
&=
\boxed{
\frac{30\log\phi}
{6+\frac{45}{2}\log\phi}
}.
\end{aligned}
\tag{10.7}
\]

### Theorem 10.1 — unconditional Catalan worthiness theorem

There exists an admissible sequence
\[
(q_n,p_n)\in\mathbf Z^2
\]
approximating Catalan's constant \(G\) such that
\[
\boxed{
\delta(q,p)
\ge
\frac{30\log\phi}
{6+\frac{45}{2}\log\phi}
=
0.8579144524736175393706930538509\ldots.
}
\tag{10.8}
\]

The value remains below the irrationality threshold \(1\); accordingly this theorem does not prove the irrationality of Catalan's constant.

---

## 11. Correction and simplification of the balanced-minima theorem

There are two minor issues worth correcting in the earlier formulation.

First, the global split

> \(r_n=o(1)\), or \(r_n\) is bounded away from \(0\)

does not literally exhaust an arbitrary oscillatory sequence \(r_n\).

Second, in the exceptional branch
\[
\ell_1=0,
\]
the replacement
\[
b_2\longmapsto b_2+N_nb_1
\]
leaves the nonzero linear form unchanged while making the height large. This proves the required *ratio* estimate, but need not preserve the separately advertised estimate
\[
\log|\ell_n|\le Fn+o(n).
\]
The original proof itself uses this ratio mechanism in that branch.

The clean theorem is therefore the following.

### Theorem 11.1 — corrected balanced two-row selection

Assume the hypotheses of the base-note two-row theorem. Put
\[
x=\frac{\sigma+E_2-E_1}{2},
\qquad
H=A_2-x,
\qquad
F=x+E_1-\sigma,
\]
with \(H,F>0\).

Then for all sufficiently large \(n\) there is a divided integer row \((q_n,p_n)\) with
\[
q_n\ne0,
\qquad
q_n\alpha-p_n\ne0,
\tag{11.1}
\]
\[
\log|q_n|
\ge
Hn-o(n),
\tag{11.2}
\]
and
\[
\boxed{
\frac{\log|q_n\alpha-p_n|}
{\log|q_n|}
\le
\frac FH+o(1).
}
\tag{11.3}
\]
Consequently
\[
\boxed{
\delta(q,p)\ge1-\frac FH.
}
\tag{11.4}
\]

### Proof

Use the balanced rectangle and successive minima
\[
\mu_{1,n}\le\mu_{2,n}
\]
of the base proof, and put
\[
r_n=-\frac1n\log\mu_{1,n}\ge0.
\]

Choose a positive sequence \(\varepsilon_n\to0\) dominating all normalized rate errors, and put
\[
\eta_n=\sqrt{\varepsilon_n}.
\]

The case distinction is now made separately for each \(n\).

#### Case A: \(r_n\le\eta_n\)

Here \(r_n=o(1)\) on the relevant scale. Both successive-minimum rows satisfy
\[
|q_i|
\le
e^{(H+o(1))n},
\qquad
|\ell_i|
\le
e^{(F+o(1))n}.
\]
The output determinant has rate
\[
(H+F)n+o(n),
\]
so at least one row satisfies
\[
\log|q_i|\ge Hn-o(n).
\]

If its linear form is nonzero, choose it. If its linear form vanishes, add or subtract the other row, choosing a sign for which the first coordinates do not cancel. Since the determinant is nonzero, the second linear form is nonzero. The same exponential bounds remain valid.

#### Case B: \(r_n>\eta_n\) and \(\ell_1\ne0\)

Choose \(m_n\in\mathbf Z\) such that
\[
0<
|\ell_2-m_n\ell_1|
\le
\frac32|\ell_1|.
\]
Put
\[
q'=q_2-m_nq_1,
\qquad
\ell'=\ell_2-m_n\ell_1.
\]

Since
\[
\Delta_n'=q_2\ell_1-q_1\ell_2,
\]
we have
\[
q'
=
\frac{\Delta_n'}{\ell_1}
+
q_1\frac{\ell'}{\ell_1}.
\]
Let
\[
a_n=\frac1n\log|\ell_1|.
\]
Then
\[
a_n\le F-r_n+o(1).
\]
Because
\[
r_n>\eta_n\gg\varepsilon_n,
\]
the first term in the expression for \(q'\) dominates exponentially, giving
\[
\frac1n\log|q'|
=
H+F-a_n+o(1).
\]
Meanwhile
\[
\log|\ell'|\le a_nn+O(1).
\]
Since
\[
a\longmapsto\frac{a}{H+F-a}
\]
is increasing,
\[
\frac{\log|\ell'|}{\log|q'|}
\le
\frac{F-r_n+o(1)}
{H+r_n-o(1)}
\le
\frac FH+o(1).
\]
Also
\[
\log|q'|\ge Hn-o(n).
\]

#### Case C: \(\ell_1=0\)

The nonzero determinant forces
\[
q_1\ne0,
\qquad
\ell_2\ne0.
\]
Choose a constant \(C>H\), sufficiently large relative to an eventual exponential upper bound for \(\ell_2\), and put
\[
N_n=\lceil e^{Cn}\rceil.
\]
Replace the second row by
\[
b_2+N_nb_1.
\]
Its linear form remains exactly
\[
\ell_2\ne0,
\]
whereas its first coordinate has logarithmic size
\[
Cn+o(n).
\]
Choosing \(C\) sufficiently large gives
\[
\frac{\log|\ell_2|}
{\log|q_2+N_nq_1|}
<
\frac FH+o(1).
\]

These three per-\(n\) alternatives cover every sufficiently large \(n\), including oscillatory \(r_n\). This proves (11.1)–(11.4). \(\square\)

The corrected theorem states exactly the invariant needed for construction quality and removes an unnecessary stronger assertion.

---

## 12. Revised dependency graph

There is now no unresolved arithmetic hypothesis.

### Previously imported established inputs

As in the base note:

- the Zudilin recurrence and its denominator and archimedean estimates;
- the modular \(E\)-recurrence, arithmetic estimates, archimedean rates, and Wronskian;
- \(\log D_N=N+o(N)\);
- Minkowski's second theorem.

### Additional established inputs used here

**B1.** Beukers's Padé recurrence and Padé identity.

**B2.** Beukers's Proposition 7.1(4), especially the uniform bound
\[
|p_n(a/2)-\Xi(a/2)q_n(a/2)|_2
\le4n^2\,2^{-4n}.
\]

**R1.** Rivoal's explicit Padé polynomial formulas, giving
\[
q_n(x)=\mathscr P_{2n}(1-2x),
\qquad
p_n(x)=\frac4{1-2x}\mathscr Q_{2n}(1-2x).
\]

**R2.** Rivoal's Theorem 2 and the exact Catalan numerator formula.

### New internal results

The present note proves:

1. the moving-orbit formula
   \[
   \Xi(x_m)=(-1)^m(\xi-8\sigma_m);
   \]

2. the normalized moving-point convergence;

3. 
   \[
   \mathcal G_{Z,2}=\xi/8;
   \]

4. the quadratic pullback
   \[
   \mathscr L_E[gy(t)]=16z(L_By)(t);
   \]

5. the generating-function identities for \(A(z)\) and \(B(z)\);

6. the coefficientwise estimate
   \[
   v_2(16B_n-\xi A_n)\ge5n-O(\log n);
   \]

7.
   \[
   \mathcal G_{E,2}=\xi/8;
   \]

8.
   \[
   \mathcal G_{Z,2}=\mathcal G_{E,2};
   \]

9.
   \[
   v_2(P_mA_{2m}-2B_{2m}Q_m)=4m-1;
   \]

10. the unconditional divisor
    \[
    2^{24n};
    \]

11. the unconditional \(0.857914\) worthiness bound;

12. the corrected balanced-minima formulation.

The earlier exact computation for \(m\le100\) can therefore be retained only as a numerical check; it is no longer part of the logical argument.

---

## 13. Conceptual interpretation

The identity
\[
\mathcal G_{Z,2}=\mathcal G_{E,2}
\]
is not merely an accidental congruence between two recurrence sequences.

The Zudilin realization reaches the common \(2\)-adic coordinate through a moving-point Padé specialization
\[
x_m=\frac12-m.
\]
Its motion is absorbed exactly by the functional equation of the Padé function.

The modular \(E\)-realization reaches the same coordinate through the fixed Padé point
\[
x=\frac12
\]
transported by the quadratic map
\[
t=16z(1-4z).
\]

Thus the two real Catalan constructions are different realizations of one finite-place extension coordinate. Their cross determinant detects this common coordinate in exterior degree two. The resulting factor
\[
2^{24n}
\]
is genuinely a cross-realization divisor: it is invisible in the denominator arithmetic of either row by itself.

That is the structural origin of the gain to
\[
0.8579144524\ldots.
\]

---

## References

**[B]** F. Beukers, *Irrationality of some p-adic L-values*, arXiv:math/0603277v2 (2006), especially Sections 4, 6, and Proposition 7.1.

**[R]** T. Rivoal, *Nombres d'Euler, approximants de Padé et constante de Catalan* (2006), especially the Padé-polynomial construction and Theorem 2.

**[Base]** *A Conditional \(0.857914\) Catalan Worthiness Theorem from a \(2\)-adic Cross-Realization Congruence*. Its exact \(2\)-adic tails and downstream lattice construction are retained.

---

## Final theorem

The word **conditional** can be removed.

Relative only to the established imported results explicitly listed above, there exists an admissible sequence of rational approximations to Catalan's constant satisfying
\[
\boxed{
\delta_{\rm Cat}
\ge
\frac{30\log\phi}
{6+\frac{45}{2}\log\phi}
=
0.8579144524736175393706930538\ldots.
}
\]

The arithmetic hinge is now a theorem:
\[
\boxed{
v_2(P_mA_{2m}-2B_{2m}Q_m)=4m-1
\qquad(m\ge1).
}
\]

No Gap Hypothesis remains.
::: ​​