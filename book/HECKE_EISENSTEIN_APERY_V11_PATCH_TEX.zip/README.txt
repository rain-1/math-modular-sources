V9 INTEGRATION PATCH
====================

Purpose
-------
Drop-in theory/application material for the foundational Hecke--Eisenstein Apéry paper after V8.

Files
-----
three_layer_v9_patch.tex
  Adds the horizontal-integration profile e to the adelic realization and defines the fine penalty tau_ad=tau_F+tau_hor.

boundary_franke_layerB_patch.tex
  Replaces the former open boundary-completed Franke problem by the completed critical--orientation--boundary exact theory.

cdt_adelic_rederivation.tex
  Reconstructs the successful Calegari--Dimitrov--Tang L(2,chi_-3) proof inside the three-layer formalism, including the exact free-depth flag 14 -> 3 -> 1, tau_F=191/49, e, tau_hor=27/80, and tau_ad=16603/3920.

main.tex
  Standalone compilable integration supplement.

Suggested V8->V9 changes
------------------------
1. Replace the old open boundary-completed Franke problem/status with the theorem in boundary_franke_layerB_patch.tex.
2. Extend the Layer-C realization tuple by e as in three_layer_v9_patch.tex.
3. Replace the earlier CDT benchmark discussion by the reconstruction theorem in cdt_adelic_rederivation.tex.
4. Change the research programme: the next new quantitative problem is the punctured-genus-one energy for the L(3,chi_5) six-sheet construction.
